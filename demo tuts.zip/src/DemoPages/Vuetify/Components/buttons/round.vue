<template>
  <div class="text-xs-center">
    <v-btn round color="primary" dark>Rounded Button</v-btn>
  </div>
</template>
