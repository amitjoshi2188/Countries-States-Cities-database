<template>
  <div class="text-xs-center">
    <v-btn outline color="indigo">Outline Button</v-btn>
    <v-btn outline fab color="teal">
      <v-icon>list</v-icon>
    </v-btn>
    <v-btn outline large fab color="indigo">
      <v-icon>edit</v-icon>
    </v-btn>
  </div>
</template>
