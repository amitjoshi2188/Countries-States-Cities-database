<template>
  <v-card>
    <v-card-text>
      <p class="text-lg-right">Right align on large viewport sizes</p>
      <p class="text-md-center">Center align on medium viewport sizes</p>
      <p class="text-sm-left">Left align on small viewport sizes</p>
      <p class="text-xs-center">Center align on all viewport sizes</p>
      <p class="text-xs-right">Right align on all viewport sizes</p>
    </v-card-text>
  </v-card>
</template>
