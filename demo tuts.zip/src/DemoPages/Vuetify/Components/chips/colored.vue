<template>
  <div class="text-xs-center">
    <v-chip color="primary" text-color="white">Primary</v-chip>

    <v-chip color="secondary" text-color="white">Secondary</v-chip>

    <v-chip color="red" text-color="white">Colored Chip</v-chip>

    <v-chip color="green" text-color="white">Colored Chip</v-chip>
  </div>
</template>
