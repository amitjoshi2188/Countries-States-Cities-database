<template>
  <div class="text-xs-center">
    <v-chip label>Label</v-chip>

    <v-chip label color="pink" text-color="white">
      <v-icon left>label</v-icon>Tags
    </v-chip>

    <v-chip label outline color="red">Outline</v-chip>
  </div>
</template>
