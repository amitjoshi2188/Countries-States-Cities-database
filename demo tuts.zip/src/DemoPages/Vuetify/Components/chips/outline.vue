<template>
  <div class="text-xs-center">
    <v-chip outline color="secondary">Outline</v-chip>

    <v-chip outline color="primary">Colored</v-chip>

    <v-chip outline color="red">
      <v-icon left>build</v-icon>Icon
    </v-chip>
  </div>
</template>
