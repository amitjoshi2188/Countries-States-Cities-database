<template>
  <div class="text-xs-center">
    <v-chip color="indigo" text-color="white">
      <v-avatar>
        <v-icon>account_circle</v-icon>
      </v-avatar>
      Ranee
    </v-chip>

    <v-chip color="orange" text-color="white">
      Premium
      <v-icon right>star</v-icon>
    </v-chip>

    <v-chip color="primary" text-color="white">
      1 Year
      <v-icon right>cake</v-icon>
    </v-chip>

    <v-chip color="green" text-color="white">
      <v-avatar class="green darken-4">1</v-avatar>
      Years
    </v-chip>

    <v-chip close color="teal" text-color="white">
      <v-avatar>
        <v-icon>check_circle</v-icon>
      </v-avatar>
      Confirmed
    </v-chip>
  </div>
</template>
