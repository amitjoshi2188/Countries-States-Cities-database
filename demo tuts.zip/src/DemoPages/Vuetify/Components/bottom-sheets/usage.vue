<template>
    <div class="text-xs-center">
        <v-bottom-sheet v-model="sheet">
            <template v-slot:activator>
                <v-btn
                    color="purple"
                    dark
                >
                    Click me
                </v-btn>
            </template>
            <v-list>
                <v-subheader>Open in</v-subheader>
                <v-list-tile
                    v-for="tile in tiles"
                    :key="tile.title"
                    @click="sheet = false"
                >
                    <v-list-tile-avatar>
                        <v-avatar size="32px" tile>
                            <img
                                :src="`https://cdn.vuetifyjs.com/images/bottom-sheets/${tile.img}`"
                                :alt="tile.title"
                            >
                        </v-avatar>
                    </v-list-tile-avatar>
                    <v-list-tile-title>{{ tile.title }}</v-list-tile-title>
                </v-list-tile>
            </v-list>
        </v-bottom-sheet>
    </div>
</template>

<script>
    export default {
        data: () => ({
            sheet: false,
            tiles: [
                { img: 'keep.png', title: 'Keep' },
                { img: 'inbox.png', title: 'Inbox' },
                { img: 'hangouts.png', title: 'Hangouts' },
                { img: 'messenger.png', title: 'Messenger' },
                { img: 'google.png', title: 'Google+' }
            ]
        })
    }
</script>