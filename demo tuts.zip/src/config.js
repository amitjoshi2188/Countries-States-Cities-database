export default {
    /*below values must be same as usertype table having as per role starts */
    superAdmin: 1,
    distributer: 2,
    companyAdmin: 3,
    companyUser: 4,
    referralUser: 5,
    customer: 6,
    /*below values must be same as usertype table having as per role ends */
    projectModule: 'Projects', // name must be as => pro-d\src\router\index.js having in routes
    productModule: 'Products', // name must be as => pro-d\src\router\index.js having in routes
};
