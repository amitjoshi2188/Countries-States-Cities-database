<template>
  <div>
    <project-page-title
      :projectheading="heading"
      :projectsubheading="subheading"
      :projecticon="icon"
    ></project-page-title>
    <div class="content">
      <b-card class="main-card mb-4">
        <h6>
          <b>My Projects</b>
        </h6>
        <span>Projects created by you</span>
        <p></p>
        <div class>
          <v-dialog v-model="dialog" width="700">
            <template v-slot:activator="{ on }">
              <v-layout row>
                <v-flex col-md-3 class="pro_card_Margin" v-on="on">
                  <v-card height="100px">
                    <v-card-text>
                      <h6 style="text-align: center;">
                        <b>Google Company Project</b>
                      </h6>
                      <b-row>
                        <b-col md="6">
                          <Label for="exampleEmail">Shared with:</Label>
                          <p>5 others</p>
                        </b-col>
                        <b-col md="6">
                          <Label for="exampleEmail">Orders:</Label>
                          <p>8 Orders</p>
                        </b-col>
                      </b-row>
                    </v-card-text>
                  </v-card>
                </v-flex>
                <v-flex col-md-3 class="pro_card_Margin" v-on="on">
                  <v-card height="100px">
                    <v-card-text>
                      <h6 style="text-align: center;">
                        <b>Google Company Project</b>
                      </h6>
                      <b-row>
                        <b-col md="6">
                          <Label for="exampleEmail">Shared with:</Label>
                          <p>5 others</p>
                        </b-col>
                        <b-col md="6">
                          <Label for="exampleEmail">Orders:</Label>
                          <p>8 Orders</p>
                        </b-col>
                      </b-row>
                    </v-card-text>
                  </v-card>
                </v-flex>
              </v-layout>
            </template>
            <v-card>
              <v-card-text>
                <h5 style="text-align: center;">
                  <b>View Project Details</b>
                </h5>
                <p></p>
                <span>Project Name:</span>
                <p></p>
                <h6>
                  <b>Google Company Project</b>
                </h6>
                <b-tabs class="card-header-tab-animation" card>
                  <b-tab title="Sharing" active>
                    <span>Shared with:</span>
                    <b-row>
                      <b-col md="10">
                        <ol>
                          <li>
                            John Deo (john@mail.com)
                            <i class="pe-7s-trash trash_icon"></i>
                          </li>
                          <li>
                            John Deo (john@mail.com)
                            <i class="pe-7s-trash trash_icon"></i>
                          </li>
                        </ol>
                      </b-col>
                      <!-- <b-col md="2">
                                 <i class="pe-7s-trash" style="font-size: 20px;"></i>
                      </b-col>-->
                    </b-row>
                    <v-divider></v-divider>
                    <b-row>
                      <b-col md="8">
                        <b-form-group>
                          <Label for="exampleEmail">Share with Others</Label>
                          <b-form-input type="email" name id placeholder="Enter email addresses" />
                        </b-form-group>
                      </b-col>
                      <b-col md="2" style="margin-top: 30px;">
                        <i class="lnr-user" style="font-size: 25px;"></i>
                      </b-col>
                    </b-row>
                    <div style="text-align:center;">
                      <button
                        type="button"
                        class="btn mr-2 mb-2 btn-success"
                        @click="dialog = false"
                      >Done</button>
                    </div>
                  </b-tab>
                  <b-tab title="Orders">
                    <b-row>
                      <b-col md="8" class="my-1 col-sm-6">
                        <b-form-group horizontal label="Show Records" class="mb-0">
                          <b-form-select :options="pageOptions" v-model="perPage" />
                        </b-form-group>
                      </b-col>
                      <b-col md="4" class="my-1 col-sm-6">
                        <b-form-group horizontal label class="mb-0">
                          <b-input-group>
                            <b-form-input v-model="filter" placeholder="Search" />
                          </b-input-group>
                        </b-form-group>
                      </b-col>
                    </b-row>
                    <p></p>
                    <!-- Main table element -->
                    <b-table
                      bordered
                      show-empty
                      stacked="md"
                      :items="items"
                      :fields="fields"
                      :current-page="currentPage"
                      :per-page="perPage"
                      :filter="filter"
                      :sort-by.sync="sortBy"
                      :sort-direction="sortDirection"
                      @filtered="onFiltered"
                    >
                      <template slot="srno" slot-scope="row">{{row.value}}</template>
                      <template slot="createdon" slot-scope="row">{{row.value}}</template>
                      <template slot="paymentstatus" slot-scope="row">{{row.value}}</template>
                      <template slot="actions" slot-scope="row">
                        <i class="lnr-exit-up set_icon"></i>
                      </template>
                      <template slot="row-details" slot-scope="row">
                        <b-card class="no-shadow">
                          <ul class="list-group">
                            <li
                              class="list-group-item"
                              v-for="(value, key) in row.item"
                              :key="key"
                            >{{ key }}: {{ value}}</li>
                          </ul>
                        </b-card>
                      </template>
                    </b-table>
                    <b-row>
                      <b-col md="6" class="my-1">
                        <b-pagination
                          :total-rows="totalRows"
                          :per-page="perPage"
                          v-model="currentPage"
                          class="my-0"
                        />
                      </b-col>
                    </b-row>
                  </b-tab>
                </b-tabs>
              </v-card-text>
            </v-card>
          </v-dialog>
        </div>
      </b-card>
      <b-card class="main-card mb-4">
        <h6>
          <b>Shared with Me</b>
        </h6>
        <span>Other projects which are shared with me.</span>
        <p></p>
        <div class>
          <v-dialog v-model="dialog" width="700">
            <template v-slot:activator="{ on }">
              <v-layout row>
                <v-flex col-md-3 class="pro_card_Margin" v-on="on">
                  <v-card height="100px">
                    <v-card-text>
                      <h6 style="text-align: center;">
                        <b>Google Company Project</b>
                      </h6>
                      <b-row>
                        <b-col md="6">
                          <Label for="exampleEmail">Shared by:</Label>
                          <p>John Deo</p>
                        </b-col>
                        <b-col md="6">
                          <Label for="exampleEmail">Orders:</Label>
                          <p>8 Orders</p>
                        </b-col>
                      </b-row>
                    </v-card-text>
                  </v-card>
                </v-flex>
                <v-flex col-md-3 class="pro_card_Margin" v-on="on">
                  <v-card height="100px">
                    <v-card-text>
                      <h6 style="text-align: center;">
                        <b>Google Company Project</b>
                      </h6>
                      <b-row>
                        <b-col md="6">
                          <Label for="exampleEmail">Shared by:</Label>
                          <p>John Deo</p>
                        </b-col>
                        <b-col md="6">
                          <Label for="exampleEmail">Orders:</Label>
                          <p>8 Orders</p>
                        </b-col>
                      </b-row>
                    </v-card-text>
                  </v-card>
                </v-flex>
              </v-layout>
            </template>
            <v-card>
              <v-card-text>
                <h5 style="text-align: center;">
                  <b>View Project Details</b>
                </h5>
                <p></p>
                <span>Project Name:</span>
                <p></p>
                <h6>
                  <b>Google Company Project</b>
                </h6>
                <b-tabs class="card-header-tab-animation" card>
                  <b-tab title="Sharing" active>
                    <span>Shared with:</span>
                    <b-row>
                      <b-col md="10">
                        <ol>
                          <li>
                            John Deo (john@mail.com)
                            <i class="pe-7s-trash trash_icon"></i>
                          </li>
                          <li>
                            John Deo (john@mail.com)
                            <i class="pe-7s-trash trash_icon"></i>
                          </li>
                        </ol>
                      </b-col>
                      <!-- <b-col md="2">
                                 <i class="pe-7s-trash" style="font-size: 20px;"></i>
                      </b-col>-->
                    </b-row>
                    <v-divider></v-divider>
                    <b-row>
                      <b-col md="8">
                        <b-form-group>
                          <Label for="exampleEmail">Share with Others</Label>
                          <b-form-input type="email" name id placeholder="Enter email addresses" />
                        </b-form-group>
                      </b-col>
                      <b-col md="2" style="margin-top: 30px;">
                        <i class="lnr-user" style="font-size: 25px;"></i>
                      </b-col>
                    </b-row>
                    <div style="text-align:center;">
                      <button
                        type="button"
                        class="btn mr-2 mb-2 btn-success"
                        @click="dialog = false"
                      >Done</button>
                    </div>
                  </b-tab>
                  <b-tab title="Orders">
                    <b-row>
                      <b-col md="8" class="my-1 col-sm-6">
                        <b-form-group horizontal label="Show Records" class="mb-0">
                          <b-form-select :options="pageOptions" v-model="perPage" />
                        </b-form-group>
                      </b-col>
                      <b-col md="4" class="my-1 col-sm-6">
                        <b-form-group horizontal label class="mb-0">
                          <b-input-group>
                            <b-form-input v-model="filter" placeholder="Search" />
                          </b-input-group>
                        </b-form-group>
                      </b-col>
                    </b-row>
                    <p></p>
                    <!-- Main table element -->
                    <b-table
                      bordered
                      show-empty
                      stacked="md"
                      :items="items"
                      :fields="fields"
                      :current-page="currentPage"
                      :per-page="perPage"
                      :filter="filter"
                      :sort-by.sync="sortBy"
                      :sort-direction="sortDirection"
                      @filtered="onFiltered"
                    >
                      <template slot="srno" slot-scope="row">{{row.value}}</template>
                      <template slot="createdon" slot-scope="row">{{row.value}}</template>
                      <template slot="paymentstatus" slot-scope="row">{{row.value}}</template>
                      <template slot="actions" slot-scope="row">
                        <i class="lnr-exit-up set_icon"></i>
                      </template>
                      <template slot="row-details" slot-scope="row">
                        <b-card class="no-shadow">
                          <ul class="list-group">
                            <li
                              class="list-group-item"
                              v-for="(value, key) in row.item"
                              :key="key"
                            >{{ key }}: {{ value}}</li>
                          </ul>
                        </b-card>
                      </template>
                    </b-table>
                    <b-row>
                      <b-col md="6" class="my-1">
                        <b-pagination
                          :total-rows="totalRows"
                          :per-page="perPage"
                          v-model="currentPage"
                          class="my-0"
                        />
                      </b-col>
                    </b-row>
                  </b-tab>
                </b-tabs>
              </v-card-text>
            </v-card>
          </v-dialog>
        </div>
      </b-card>
    </div>
  </div>
</template>
<script>
import projectPageTitle from "../../../Layout/Components/projectPageTitle.vue";

const items = [
  { srno: 1234, createdon: "July 8,2019", paymentstatus: "Paid" },
  { srno: 1235, createdon: "July 7,2019", paymentstatus: "Pending" }
];
export default {
  components: {
    projectPageTitle
  },
  data: () => ({
    heading: "Projects > View Projects",
    subheading: "Manage all your projects",
    icon: "pe-7s-check",
    dialog: false,
    items: items,
    fields: [
      { key: "srno", label: "B.Order#", sortable: 1, sortDirection: "desc" },
      { key: "createdon", label: "Created On", sortable: 1 },
      { key: "paymentstatus", label: "Payment Status", sortable: 1 },
      { key: "actions", label: "Actions" }
    ],
    currentPage: 1,
    perPage: 5,
    totalRows: items.length,
    pageOptions: [5, 10, 15],
    sortBy: null,
    sortDirection: "asc",
    filter: null
  }),
  methods: {
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    }
  }
};
</script>
<style>
.v-dialog:not(.v-dialog--fullscreen) {
  max-height: 100%;
}
.pro_card_Margin {
  margin-bottom: 15px;
  cursor: pointer;
}
.trash_icon {
  font-size: 20px !important;
  position: fixed !important;
  margin-left: 15% !important;
}
li {
  margin-block-start: 10px;
}
</style>