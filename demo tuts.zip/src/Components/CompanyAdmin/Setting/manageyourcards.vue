<template>
    <div>
        <setting-page-title :settingsheading=heading :settingssubheading=subheading :settingsicon=icon></setting-page-title>
        <div class="content">
            <b-row>
                <b-col md="12">
                    <b-card class="mb-3" no-body>
                        <b-tabs class="card-header-tab-animation" card>
                            <b-tab title="Profile Settings">
                                <!-- first tab code -->
                            </b-tab>
                            <b-tab title="Your Cards" active>
                                <b-row>
                                    <b-col md="10">
                                        <h5 v-if="visaCard">You do not have any cards added. Please click below to add new card.</h5>
                                        <v-layout row v-if="!visaCard">
                                            <v-flex col-md-3 class="seeting_viza_card_Margin">
                                                <v-card height="135px" style="border: 4px solid #3ac47d;">
                                                    <v-card-text>
                                                        <img width="42" style="margin-bottom: 10px;" src="../../../assets/images/visa.png">
                                                        <b-form-group>
                                                            <b-form-input type="text" name="" id="" placeholder="**** **** **** 1234"/>
                                                        </b-form-group>
                                                        <b-row>
                                                            <b-col md="6">
                                                                <Label>Expires: 01/22</Label>
                                                            </b-col>
                                                            <b-col md="6" style="text-align: right;">
                                                                <Label style="color: #3ac47d" v-if="!primaryHideShow">Primary</Label>
                                                            </b-col>
                                                        </b-row>
                                                    </v-card-text>
                                                </v-card>
                                            </v-flex>
                                            <v-flex col-md-3 class="seeting_viza_card_Margin">
                                                <v-card height="135px">
                                                    <v-card-text>

                                                        <img width="42" style="margin-bottom: 10px;" src="../../../assets/images/visa.png">
                                                        <b-form-group>
                                                            <b-form-input type="text" name="" id="" placeholder="**** **** **** 1234"/>
                                                        </b-form-group>
                                                        <b-row>
                                                            <b-col md="6">
                                                                <Label>Expires: 01/22</Label>
                                                            </b-col>
                                                            <b-col md="6" style="text-align: right;">
                                                                <Label v-if="primaryHideShow">Primary</Label>
                                                            </b-col>
                                                        </b-row>
                                                    </v-card-text>
                                                </v-card>
                                            </v-flex>
                                        </v-layout>
                                    </b-col>  
                                    <b-col md="2" style="text-align: right;">
                                        <!-- <button type="button" v-on="on" class="btn-shadow d-inline-flex align-items-center btn btn-success">Add a card</button> -->
                                        <div class="text-xs-center">
                                            <v-dialog v-model="dialog" width="700">
                                                <template v-slot:activator="{ on }">
                                                    <v-btn style="background-color: #3ac47d !important;" color="red lighten-2" dark v-on="on">
                                                        Add a card
                                                    </v-btn>
                                                </template>
                                                <v-card>
                                                    <v-card-title class="lighten-2">Add a New Card</v-card-title>
                                                    <v-divider></v-divider>
                                                    <v-card-text>
                                                        <b-row form>
                                                            <b-col md="6">
                                                                <h6 style="margin-bottom: 1.5rem;">Enter Your Card Details:</h6>
                                                                <b-form-group>
                                                                    <Label for="exampleEmail">Name on Card</Label>
                                                                    <b-form-input type="text" name="" id="" placeholder="John Deo"/>
                                                                </b-form-group>
                                                                <b-form-group>
                                                                    <Label for="exampleEmail">Crad Number</Label>
                                                                    <b-form-input type="text" name="" id="" placeholder=""/>
                                                                </b-form-group>
                                                                <b-row>
                                                                    <b-col md="6">
                                                                        <b-form-group>
                                                                            <Label for="exampleEmail">Expiry</Label>
                                                                            <b-form-input type="text" name="" id="" placeholder=""/>
                                                                        </b-form-group>
                                                                    </b-col>
                                                                    <b-col md="6">
                                                                        <b-form-group>
                                                                            <Label for="exampleEmail">CVV Security Number</Label>
                                                                            <b-form-input type="text" name="" id="" placeholder=""/>
                                                                        </b-form-group>
                                                                    </b-col>
                                                                </b-row>
                                                                <b-form-group>
                                                                    <Label for="exampleEmail">Description</Label>
                                                                    <b-form-input type="text" name="" id="" placeholder="Description here"/>
                                                                </b-form-group>
                                                                <b-form-group>
                                                                    <b-form-checkbox name="check" id="exampleCheck">Use this as primary</b-form-checkbox>
                                                                </b-form-group>
                                                            </b-col>
                                                            <b-col md="6">
                                                                <h6 style="margin-bottom: 1.5rem;">Enter Your Billing Details:</h6>
                                                                <b-form-group>
                                                                    <Label for="exampleEmail">Name</Label>
                                                                    <b-form-input type="text" name="" id="" placeholder="John Deo"/>
                                                                </b-form-group>
                                                                <b-form-group>
                                                                    <Label for="exampleEmail">Address</Label>
                                                                    <b-form-input type="text" name="" id="" placeholder="Address here"/>
                                                                </b-form-group>
                                                                <b-row>
                                                                    <b-col md="6">
                                                                        <b-form-group>
                                                                            <Label for="exampleEmail">City</Label>
                                                                            <b-form-input type="text" name="" id="" placeholder=""/>
                                                                        </b-form-group>
                                                                    </b-col>
                                                                    <b-col md="6">
                                                                        <b-form-group>
                                                                            <Label for="exampleEmail">State</Label>
                                                                            <b-form-input type="text" name="" id="" placeholder=""/>
                                                                        </b-form-group>
                                                                    </b-col>
                                                                </b-row>
                                                                <b-row>
                                                                    <b-col md="6">
                                                                        <b-form-group>
                                                                            <Label for="exampleEmail">Country</Label>
                                                                            <b-form-input type="text" name="" id="" placeholder=""/>
                                                                        </b-form-group>
                                                                    </b-col>
                                                                    <b-col md="6">
                                                                        <b-form-group>
                                                                            <Label for="exampleEmail">Zipcode</Label>
                                                                            <b-form-input type="text" name="" id="" placeholder=""/>
                                                                        </b-form-group>
                                                                    </b-col>
                                                                </b-row>
                                                            </b-col>
                                                        </b-row>
                                                    </v-card-text>
                                                    <v-divider></v-divider>
                                                    <v-card-actions>
                                                        <v-spacer></v-spacer>
                                                        <button type="button" class="btn mr-2 mb-2 btn-success" @click="dialog = false">Save</button>
                                                        <button type="button" class="btn mr-2 mb-2 btn-light"  @click="dialog = false">Cancel</button>
                                                    </v-card-actions>
                                                </v-card>
                                            </v-dialog>
                                        </div>
                                    </b-col> 
                                </b-row>
                            </b-tab>
                        </b-tabs>
                    </b-card>
                </b-col>
            </b-row>
        </div>
    </div>
</template>

<script>

    import settingPageTitle from "../../../Layout/Components/settingPageTitle.vue";

    export default {
        components: {
            settingPageTitle
        },
        data: () => ({
                heading: 'Settings > Manage your cards',
                subheading: 'Manage all your payment cards',
                icon: 'pe-7s-settings',
                dialog: false,
                visaCard: false,
                primaryHideShow: false
            }),
    }
</script>
<style>
    .v-dialog:not(.v-dialog--fullscreen) {
        max-height: 102% !important;
    }
    .seeting_viza_card_Margin{
        margin-bottom: 15px;
        cursor: pointer;
    }
</style>