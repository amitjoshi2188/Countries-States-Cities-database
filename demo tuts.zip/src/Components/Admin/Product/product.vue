<template>
  <div>
    <product-page-title
      :productheading="heading"
      :productsubheading="subheading"
      :producticon="icon"
    ></product-page-title>
    <!-- View All Product Start-->
    <div id="mainPage" v-if="mainpage && viewProduct && viewDetailsProduct">
      <b-card class="main-card mb-4">
        <b-row>
          <b-col md="5" class="my-1">
            <b-form-group horizontal label="Show Records" class="mb-0">
              <b-form-select :options="pageOptions" v-model="perPage" />
            </b-form-group>
          </b-col>
          <b-col md="3" class="my-1"></b-col>
          <b-col md="4" class="my-1">
            <b-form-group horizontal label class="mb-0">
              <b-input-group>
                <b-form-input v-model="filter" placeholder="Search" />
              </b-input-group>
            </b-form-group>
          </b-col>
        </b-row>
        <p></p>
        <!-- Main table element -->
        <b-table
          bordered
          show-empty
          stacked="md"
          :items="items"
          :fields="fields"
          :current-page="currentPage"
          :per-page="perPage"
          :filter="filter"
          :sort-by.sync="sortBy"
          :sort-direction="sortDirection"
          @filtered="onFiltered"
        >
          <template slot="srno" slot-scope="row">{{row.value}}</template>
          <template slot="productname" slot-scope="row">{{row.value}}</template>
          <template slot="price" slot-scope="row">{{row.value}}</template>
          <template slot="status" slot-scope="row">{{row.value}}</template>
          <template slot="actions" slot-scope="row">
            <i class="lnr-exit-up set_icon" @click="viewProductById(row.value)"></i>
          </template>
          <template slot="row-details" slot-scope="row">
            <b-card class="no-shadow">
              <ul class="list-group">
                <li
                  class="list-group-item"
                  v-for="(value, key) in row.item"
                  :key="key"
                >{{ key }}: {{ value}}</li>
              </ul>
            </b-card>
          </template>
        </b-table>
        <b-row>
          <b-col md="6" class="my-1">
            <b-pagination
              :total-rows="totalRows"
              :per-page="perPage"
              v-model="currentPage"
              class="my-0"
            />
          </b-col>
        </b-row>
      </b-card>
    </div>
    <!-- View All Product End-->
    <!-- View Product Start-->
    <div id="viewProduct" v-if="!viewProduct && viewDetailsProduct">
      <b-card class="main-card mb-4">
        <b-row>
          <b-col md="8">
            <span class="titalHeading">{{productName}}</span>
          </b-col>
          <b-col md="4" style="text-align: right !important;">
            <span v-if="status =='Active'">
              <button
                type="button"
                class="btn mr-2 mb-2 btn-danger btn-shadow"
                @click="changeStatus({productId},{status})"
              >Mark as Inactive</button>
            </span>
            <span v-if="status =='Inactive'">
              <button
                type="button"
                class="btn mr-2 mb-2 btn-success btn-shadow"
                @click="changeStatus({productId},{status})"
              >Mark as Active</button>
            </span>
            <button
              type="button"
              class="btn mr-2 mb-2 btn-warning btn-shadow"
              v-on:click="editDetailsShow()"
            >Edit Details</button>
          </b-col>
        </b-row>
        <div class="divider" />
        <b-row>
          <b-col md="2"></b-col>
          <b-col md="3">
            <span>Product Name:</span>
            <p>
              <b class="labelValue">{{productName}}</b>
            </p>
          </b-col>
          <b-col md="3">
            <span>Price ($):</span>
            <p>
              <b class="labelValue">{{price}}</b>
            </p>
          </b-col>
          <b-col md="3">
            <span>Status:</span>
            <p>
              <b class="labelValue">{{status}}</b>
            </p>
          </b-col>
          <!-- <b-col md="1"></b-col> -->
        </b-row>
        <b-row class="topSpacing">
          <b-col md="2"></b-col>
          <b-col md="3">
            <span>Referral Commission:</span>
            <p>
              <b class="labelValue">{{referralCommission}}</b>
            </p>
          </b-col>
          <b-col md="3">
            <span>Distribution Commission:</span>
            <p>
              <b class="labelValue">{{distributionCommission}}</b>
            </p>
          </b-col>
          <b-col md="4"></b-col>
        </b-row>
      </b-card>
    </div>
    <!-- View Product End-->
    <!-- View Product Start-->
    <form name="updateProductForm" id="updateProductForm" method="post" ref="updateProductForm">
      <div id="editDetails" v-if="viewProduct && !viewDetailsProduct">
        <b-card class="main-card mb-4">
          <b-row>
            <b-col md="8">
              <span class="titalHeading">{{productName}}</span>
            </b-col>
            <b-col md="4" style="text-align: right !important;">
              <button
                type="submit"
                class="btn mr-2 mb-2 btn-warning btn-shadow"
                @click.prevent="updateProduct();"
              >Save</button>
              <button
                type="button"
                class="btn mr-2 mb-2 btn-light btn-shadow"
                v-on:click="cancelForm()"
              >Cancel</button>
            </b-col>
          </b-row>
          <div class="divider" />
          <b-row>
            <b-col md="2"></b-col>
            <b-col md="3">
              <p>
                <b-form-group>
                  <Label for="productName">Product Name:</Label>
                  <input type="hidden" name="productId" v-model="productId" id="productId" />
                  <b-form-input
                    type="text"
                    name="productName"
                    v-model="productName"
                    id="productName"
                    placeholder="product Name here..."
                    required
                    title
                  />
                  <div class="text-danger" v-if="validationErrors.productName" style="width: 100%;">
                    <span v-text="validationErrors.productName"></span>
                  </div>
                </b-form-group>
              </p>
            </b-col>
            <b-col md="3">
              <p>
                <b-form-group>
                  <Label for="price">Price ($):</Label>
                  <b-form-input
                    type="number"
                    name="price"
                    v-model="price"
                    id="price"
                    required
                    placeholder="product price here..."
                    title
                  />
                  <div class="text-danger" v-if="validationErrors.price" style="width: 100%;">
                    <span v-text="validationErrors.price"></span>
                  </div>
                </b-form-group>
              </p>
            </b-col>
            <b-col md="3">
              <span>Status:</span>
              <p>
                <b class="inctive_status">Inctive</b>
                <v-switch
                  v-model="status"
                  class="switch_set"
                  color="success"
                  value="Active"
                  @change="getStatus(status)"
                  name="status"
                  id="status"
                ></v-switch>
                <b class="active_status">Active</b>
              </p>
            </b-col>
            <!-- <b-col md="1"></b-col> -->
          </b-row>

          <b-row class="topSpacing">
            <b-col md="2"></b-col>
            <b-col md="3">
              <span>Referral Commission:</span>
              <p>
                <b class="inctive_status">Disable</b>
                <v-switch
                  v-model="referralCommission"
                  class="switch_set"
                  color="success"
                  value="Active"
                  @change="getStatus(referralCommission)"
                  name="referralCommission"
                  id="referralCommission"
                ></v-switch>
                <b class="active_status">Enable</b>
              </p>
            </b-col>
            <b-col md="3">
              <span>Distribution Commission:</span>
              <p>
                <b class="inctive_status">Disable</b>
                <v-switch
                  v-model="distributionCommission"
                  class="switch_set"
                  color="success"
                  value="Active"
                  @change="getStatus(distributionCommission)"
                  name="distributionCommission"
                  id="distributionCommission"
                ></v-switch>
                <b class="active_status">Enable</b>
              </p>
            </b-col>
            <b-col md="4"></b-col>
          </b-row>
        </b-card>
      </div>
    </form>
    <!-- View Product End-->
  </div>
</template>
<script>
import productPageTitle from "../../../Layout/Components/productPageTitle.vue";
import { EventBus } from "../../../main";
// view all order table data
const items = [];
export default {
  components: {
    productPageTitle
  },
  data: () => ({
    heading: "Products > View All Products",
    subheading: "Manage your Products from here",
    icon: "pe-7s-check",
    items: items,
    fields: [
      { key: "srno", label: "Sr. No.", sortable: 1, sortDirection: "desc" },
      { key: "productname", label: "Product Name", sortable: 1 },
      { key: "price", label: "Price $", sortable: 1 },
      { key: "status", label: "Status" },
      { key: "actions", label: "Actions" }
    ],
    currentPage: 1,
    perPage: 10,
    totalRows: "",
    totalRecords: "",
    pageOptions: [5, 10, 15],
    sortBy: null,
    sortDesc: false,
    sortDirection: "asc",
    filter: null,
    modalInfo: { title: "", content: "" },
    mainpage: true,
    viewProduct: true,
    viewDetailsProduct: true,
    success: "",
    srno: "",
    productId: "",
    productName: "",
    price: "",
    status: "",
    referralCommission: "",
    distributionCommission: "",

    product: {
      srno: "",
      productId: "",
      productName: "",
      price: "",
      status: "",
      referralCommission: "",
      distributionCommission: ""
    },
    validationErrors: {
      productName: null,
      price: null
    }
  }),
  computed: {},
  mounted() {
    console.log("mounted one called");
  },
  methods: {
    /*basic alerts methods starts*/
    getStatus(status) {
      console.log(status);
    },
    /*basic alerts methods ends*/
    /* @usage       :Added to change status of product.
     * @method      :POST
     * @param       :productId   (INT)
     * @param       :status      (INT)
     * @createdBy   :Amit Joshi
     * @createdAt   :30-07-2019
     */
    changeStatus(productId, status) {
      var self = this;
      var productId = productId.productId;
      var productStatus = status.status;
      var makeStatus = "";
      var updatedStatus = "";
      if (productStatus == "Active") {
        updatedStatus = "Inactive";
        makeStatus = "0";
      }
      if (productStatus == "Inactive") {
        updatedStatus = "Active";
        makeStatus = "1";
      }

      swal({
        title: "Are you sure?",
        text:
          "Are you sure you want to " +
          self.smallFirstLetter(updatedStatus) +
          " this product?",
        icon: "warning",
        buttons: ["No", "Yes"],
        dangerMode: true
      }).then(result => {
        if (result) {
          var formdata = new FormData();
          formdata.append("productId", productId);
          formdata.append("status", makeStatus);
          axios({
            method: "post",
            url: "ProductController/changeStatus",
            data: formdata
          })
            .then(function(response) {
              if (response.data.status) {
                self.status = updatedStatus;
                self.successMsg(response.data.message, self.$route.name);
                self.products();
              } else {
                self.errorMsg(response.data.error);
              }
            })
            .catch(function(error) {
              console.log(error);
            });
        }
      });
    },
    onFiltered(filteredItems) {
      // Trigger pagination to update the number of buttons/pages due to filtering
      this.totalRows = filteredItems.length;
      this.currentPage = 1;
    }, // handal click view Order page show
    /* @usage       :Added to get Product detail by id.
     * @method      :GET
     * @param       :productId   (INT)
     * @createdBy   :Amit Joshi
     * @createdAt   :30-07-2019
     */
    viewProductById(productId) {
      var self = this;
      this.viewProduct = false;
      this.heading = "Product Detail > View Product";
      this.subheading = "View Product Details";
      axios({
        method: "get",
        url: "ProductController/getProductById",
        params: {
          productId: productId
        }
      })
        .then(function(response) {
          if (response.data.status) {
            self.productId = response.data.data["id"];
            self.productName = response.data.data["name"];
            self.price = response.data.data["price"];
            self.status =
              response.data.data.status == "1" ? "Active" : "Inactive";
            self.referralCommission =
              response.data.data.referralCommission == "1"
                ? "Active"
                : "Inactive";
            self.distributionCommission =
              response.data.data.distributionCommission == "1"
                ? "Active"
                : "Inactive";

            /*before edit data starts*/
            self.product.productId = self.productId;
            self.product.productName = self.productName;
            self.product.price = self.price;
            self.product.status = self.status;
            self.product.referralCommission = self.referralCommission;
            self.product.distributionCommission = self.distributionCommission;
            console.log(self.product);
            /*before edit data ends*/
          } else {
            self.errorMsg(response.data.error);
          }
        })
        .catch(function(error) {
          console.log(error);
        });
      EventBus.$emit("viewProductbtn", this.viewProduct);
    },
    editDetailsShow() {
      // var self = this;
      this.viewDetailsProduct = false;
      this.viewProduct = true;
      this.mainpage = false;
    },
    /* @usage       :Added to Update product details.
     * @method      :POST
     * @param       :productId
     * @param       :status
     * @param       :referralCommission
     * @param       :distributionCommission
     * @createdBy   :Amit Joshi
     * @createdAt   :30-07-2019
     */
    updateProduct() {
      if (this.validateForm("updateProductForm")) {
        var self = this;

        var formdata = new FormData(this.$refs.updateProductForm);
        if (self.status == "Active") {
          formdata.append("status", "1");
        }
        if (self.status == null || self.status == "Inactive") {
          formdata.append("status", "0");
          self.status = "Inactive";
        }
        if (self.referralCommission == "Active") {
          formdata.append("referralCommission", "1");
        } else if (
          self.referralCommission == null ||
          self.referralCommission == "Inactive"
        ) {
          formdata.append("referralCommission", "0");
          self.referralCommission = "Disable";
        } else {
          formdata.append("referralCommission", "0");
        }
        if (self.distributionCommission == "Active") {
          formdata.append("distributionCommission", "1");
        } else if (
          self.distributionCommission == null ||
          self.distributionCommission == "Inactive"
        ) {
          formdata.append("distributionCommission", "0");
          self.distributionCommission = "Disable";
        } else {
          formdata.append("distributionCommission", "0");
        }
        axios({
          method: "post",
          url: "ProductController/updateProduct",
          data: formdata
        })
          .then(function(response) {
            if (response.data.status) {
              self.editDetailsHide();
              //   self.status = updatedStatus;
              self.successMsg(response.data.message, self.$route.name);
              self.products();
            } else {
              self.errorMsg(response.data.error);
            }
          })
          .catch(function(error) {
            console.log(error);
          });
      }
    },
    cancelForm() {
      var self = this;
      self.editDetailsHide();
      /*before edit data starts*/
      self.productId = self.product.productId;
      self.productName = self.product.productName;
      self.price = self.product.price;
      self.status = self.product.status;
      self.referralCommission = self.product.referralCommission;
      self.distributionCommission = self.product.distributionCommission;
      console.log(self.product);
      /*before edit data ends*/
    },
    /*Added to update products ends*/

    /* @usage       :Added to Get listing of products.
     * @method      :GET
     * @createdBy   :Amit Joshi
     * @createdAt   :30-07-2019
     */
    products() {
      var self = this;
      axios({
        method: "get",
        url: "ProductController/getAllProducts",
        params: {}
      })
        .then(function(response) {
          if (response.data.status) {
            self.items = [];
            self.totalRecords = 0;
            Object.keys(response.data.data).forEach(function(key) {
              var srno = response.data.data[key]["id"];
              var productname = response.data.data[key]["name"];
              var price = response.data.data[key]["price"];
              //var label = response.data.data[key]["label"];
              //var description = response.data.data[key]["description"];
              var status =
                response.data.data[key]["status"] == "1"
                  ? "Active"
                  : "Inactive";

              self.items.push({
                srno: srno,
                productname: productname,
                price: price,
                status: status,
                actions: srno
              });
              self.totalRecords++;
            });
          } else {
            self.errorMsg(response.data.error);
          }
          self.totalRows = self.totalRecords;
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    /*product listing ends*/
    editDetailsHide() {
      this.viewDetailsProduct = true;
      this.viewProduct = false;
      this.mainpage = false;
    }
  },

  created() {
    EventBus.$on("mainpageShow", data => {
      this.mainpage = data;
      this.viewProduct = data;
      this.viewDetailsProduct = data;
      this.heading = "Products > View All Products";
      this.subheading = "Manage your Products from here";
    });
    this.products();
  }
};
</script>
<style>
.set_icon {
  font-size: 20px;
  cursor: pointer;
}
</style>
