<template>
    <div>
        <setting-page-title :settingsheading=heading :settingssubheading=subheading :settingsicon=icon></setting-page-title>
        <div class="content">
            <div class="row">
                <div class="col-md-2">
                    <h5>Choose Product :</h5>
                </div>
                <div class="col-md-2">
                    <div class="position-relative form-group">
                        <select type="select" id="" name="customSelect" class="custom-select">
                            <option value="">Premium</option>
                            <option>Value 1</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-9"></div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="main-card mb-3 card">
                        <div class="card-header">
                            <b>Distributor Commission</b>
                            <div class="btn-actions-pane-right actions-icon-btn">
                                <button class="btn btn-warning">Edit</button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-5">
                                    <span>Flat rate per Order:</span>
                                    <v-card-text>
                                        <v-layout justify-space-between mb-3>
                                            <v-flex text-xs-left>
                                                <span class="font-weight-light mr-1">$</span>
                                                <span class="font-weight-light" v-text="flatrate"></span>
                                                <v-fade-transition>
                                                    <v-avatar v-if="flatrateIsPlaying" :flatratecolor="flatratecolor" :style="{flatrateanimationDuration: flatrateanimationDuration}" class="mb-1 v-avatar--metronome" size="12"></v-avatar>
                                                </v-fade-transition>
                                            </v-flex>
                                        </v-layout>
                                        <v-slider v-model="flatrate" :flatratecolor="flatratecolor" always-dirty min="40" max="218">
                                            <template v-slot:prepend>
                                                <v-icon :flatratecolor="flatratecolor" @click="flatratedecrement">mdi-minus</v-icon>
                                            </template>
                                            <template v-slot:append>
                                                <v-icon :flatratecolor="flatratecolor" @click="flatrateincrement">mdi-plus</v-icon>
                                            </template>
                                        </v-slider>
                                    </v-card-text>
                                </div>
                                <div class="col-md-5">
                                    <span>Percentage of CC Fee:</span>
                                    <v-card-text>
                                        <v-layout justify-space-between mb-3> 
                                            <v-flex text-xs-left>
                                                <span class="font-weight-light" v-text="ccfee"></span>
                                                <span class="font-weight-light mr-1">%</span>
                                                <v-fade-transition>
                                                    <v-avatar v-if="ccfeeIsPlaying" :ccfeecolor="ccfeecolor" :style="{ccfeeanimationDuration: ccfeeanimationDuration}" class="mb-1 v-avatar--metronome" size="12"></v-avatar>
                                                </v-fade-transition>
                                            </v-flex>
                                        </v-layout>
                                        <v-slider v-model="ccfee" :ccfeecolor="ccfeecolor" always-dirty min="40" max="218">
                                            <template v-slot:prepend>
                                                <v-icon :ccfeecolor="ccfeecolor" @click="ccfeedecrement">mdi-minus</v-icon>
                                            </template>
                                            <template v-slot:append>
                                                <v-icon :ccfeecolor="ccfeecolor" @click="ccfeeincrement">mdi-plus</v-icon>
                                            </template>
                                        </v-slider>
                                    </v-card-text>
                                </div>
                                <div class="col-md-1"></div>
                            </div> 
                            <p></p>
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-5">
                                    <span>Admin percentage</span>
                                    <v-card-text>
                                        <v-layout justify-space-between mb-3>
                                            <v-flex text-xs-left>
                                                <span class="font-weight-light" v-text="adminpercentage"></span>
                                                <span class="font-weight-light mr-1">%</span>
                                                <v-fade-transition>
                                                    <v-avatar v-if="adminpercentageIsPlaying" :adminpercentagecolor="adminpercentagecolor" :style="{adminpercentageanimationDuration: adminpercentageanimationDuration}" class="mb-1 v-avatar--metronome" size="12"></v-avatar>
                                                </v-fade-transition>
                                            </v-flex>
                                        </v-layout>
                                        <v-slider v-model="adminpercentage" :adminpercentagecolor="adminpercentagecolor" always-dirty min="40" max="218">
                                            <template v-slot:prepend>
                                                <v-icon :adminpercentagecolor="adminpercentagecolor" @click="adminpercentagedecrement">mdi-minus</v-icon>
                                            </template>
                                            <template v-slot:append>
                                                <v-icon :adminpercentagecolor="adminpercentagecolor" @click="adminpercentageincrement">mdi-plus</v-icon>
                                            </template>
                                        </v-slider>
                                    </v-card-text>
                                </div>
                                <div class="col-md-5">
                                    <span>Admin Calculation method:</span>
                                    <div class="position-relative form-group">
                                        <div>
                                            <div class="custom-radio custom-control custom-control-inline">
                                                <input type="radio" id="exampleCustomRadio" name="customRadio" class="custom-control-input" checked>
                                                <label for="exampleCustomRadio" class="custom-control-label">On Total</label>
                                            </div>
                                            <div class="custom-radio custom-control custom-control-inline">
                                                <input type="radio" id="exampleCustomRadio" name="customRadio" class="custom-control-input">
                                                <label for="exampleCustomRadio" class="custom-control-label">On Balance</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-1"></div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="main-card mb-3 card">
                        <div class="card-header">
                            <b>Referral Commission</b>
                            <div class="btn-actions-pane-right actions-icon-btn">
                                <button class="btn btn-warning">Edit</button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-5">
                                    <span>Referral percentage</span>
                                    <v-card-text>
                                        <v-layout justify-space-between mb-3>
                                            <v-flex text-xs-left>
                                                <span class="font-weight-light" v-text="referral"></span>
                                                <span class="font-weight-light mr-1">%</span>
                                                <v-fade-transition>
                                                    <v-avatar v-if="referralIsPlaying" :referralcolor="referralcolor" :style="{referralanimationDuration: referralanimationDuration}" class="mb-1 v-avatar--metronome" size="12"></v-avatar>
                                                </v-fade-transition>
                                            </v-flex>
                                        </v-layout>
                                        <v-slider v-model="referral" :referralcolor="referralcolor" always-dirty min="40" max="218">
                                            <template v-slot:prepend>
                                                <v-icon :referralcolor="referralcolor" @click="referraldecrement">mdi-minus</v-icon>
                                            </template>
                                            <template v-slot:append>
                                                <v-icon :referralcolor="referralcolor" @click="referralincrement">mdi-plus</v-icon>
                                            </template>
                                        </v-slider>
                                    </v-card-text>
                                </div>
                                <!-- <div class="col-md-5">
                                  <span>Admin Calculation method:</span>
                                </div> -->
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import settingPageTitle from "../../../Layout/Components/settingPageTitle.vue";

    export default {
        components: {
            settingPageTitle
        },
        data: () => ({
                heading: 'Settings > Commission & Referrals',
                subheading: 'Manage rates for Commission & Referrals',
                icon: 'pe-7s-check',
                // Flat rate per Order Start
                flatrate: 50,
                flatrateIsPlaying: false,
                // Flat rate per Order End
                ccfee: 2,
                ccfeeIsPlaying: false,
                adminpercentage: 2,
                adminpercentageIsPlaying: false,
                referral: 2,
                referralIsPlaying: false
            }),
        computed: {
            flatratecolor() {
                if (this.flatrate < 100)
                    return 'indigo'
                if (this.flatrate < 125)
                    return 'teal'
                if (this.flatrate < 140)
                    return 'green'
                if (this.flatrate < 175)
                    return 'orange'
                return 'red'
            },
            flatrateanimationDuration() {
                return `${60 / this.flatrate}s`
            },
            ccfeecolor() {
                if (this.ccfee < 100)
                    return 'indigo'
                if (this.ccfee < 125)
                    return 'teal'
                if (this.ccfee < 140)
                    return 'green'
                if (this.ccfee < 175)
                    return 'orange'
                return 'red'
            },
            ccfeeanimationDuration() {
                return `${60 / this.ccfee}s`
            },
            adminpercentagecolor() {
                if (this.ccfee < 100)
                    return 'indigo'
                if (this.ccfee < 125)
                    return 'teal'
                if (this.ccfee < 140)
                    return 'green'
                if (this.ccfee < 175)
                    return 'orange'
                return 'red'
            },
            adminpercentageanimationDuration() {
                return `${60 / this.ccfee}s`
            },
            referralcolor() {
                if (this.ccfee < 100)
                    return 'indigo'
                if (this.ccfee < 125)
                    return 'teal'
                if (this.ccfee < 140)
                    return 'green'
                if (this.ccfee < 175)
                    return 'orange'
                return 'red'
            },
            referralanimationDuration() {
                return `${60 / this.ccfee}s`
            }
        },
        methods: {
            flatratedecrement() {
                this.flatrate--
            },
            flatrateincrement() {
                this.flatrate++
            },
            flatratetoggle() {
                this.flatrateIsPlaying = !this.flatrateIsPlaying
            },
            ccfeedecrement() {
                this.ccfee--
            },
            ccfeeincrement() {
                this.ccfee++
            },
            ccfeetoggle() {
                this.ccfeeIsPlaying = !this.ccfeeIsPlaying
            },
            adminpercentagedecrement() {
                this.adminpercentage--
            },
            adminpercentageincrement() {
                this.adminpercentage++
            },
            adminpercentagetoggle() {
                this.adminpercentageIsPlaying = !this.adminpercentageIsPlaying
            },
            referraldecrement() {
                this.ccfee--
            },
            referralincrement() {
                this.ccfee++
            },
            referraltoggle() {
                this.ccfeeIsPlaying = !this.ccfeeIsPlaying
            },
        }
    }
</script>