
<template>
    <div>
        <user-page-title :userheading="heading" :usersubheading="subheading" :usericon="icon"></user-page-title>
        <b-card class="main-card mb-4" v-if="userTbl && createUserView">
            <b-row>
                <b-col md="5" class="my-1">
                    <b-form-group horizontal label="Show Records" class="mb-0">
                        <b-form-select :options="pageOptions" v-model="perPage" />
                    </b-form-group>
                </b-col>
                <b-col md="3" class="my-1"></b-col>
                <b-col md="4" class="my-1">
                    <b-form-group horizontal label class="mb-0">
                        <b-input-group>
                            <b-form-input v-model="filter" placeholder="Search" />
                        </b-input-group>
                    </b-form-group>
                </b-col>
            </b-row>
            <p></p>
            <!-- Main table element -->
            <b-table
                bordered
                show-empty
                stacked="md"
                :items="items"
                :fields="fields"
                :current-page="currentPage"
                :per-page="perPage"
                :filter="filter"
                :sort-by.sync="sortBy"
                :sort-direction="sortDirection"
                @filtered="onFiltered"
                >
                <template slot="srno" slot-scope="row">{{row.value}}</template>
                <template slot="username" slot-scope="row">{{row.value}}</template>
                <template slot="usertype" slot-scope="row">{{row.value}}</template>
                <template slot="status" slot-scope="row">{{row.value}}</template>
                <template slot="actions" slot-scope="row">
                    <i class="lnr-exit-up set_icon" @click="viewUserById(row)"></i>
                </template>

                <template slot="row-details" slot-scope="row">
                    <b-card class="no-shadow">
                        <ul class="list-group">
                            <li
                                class="list-group-item"
                                v-for="(value, key) in row.item"
                                :key="key"
                                >{{ key }}: {{ value}}</li>
                        </ul>
                    </b-card>
                </template>
            </b-table>
            <b-row>
                <b-col md="6" class="my-1">
                    <b-pagination
                        :total-rows="totalRows"
                        :per-page="perPage"
                        v-model="currentPage"
                        class="my-0"
                        />
                </b-col>
            </b-row>
        </b-card>
        <!-- Create User Start -->
        <b-card class="main-card mb-4" v-if="!userTbl && createUserView">
            <div class="row">
                <div class="col-md-3">
                    <h5>Select a User Type to create :</h5>
                </div>
                <div class="col-md-2">
                    <div class="position-relative form-group">
                        <select
                            type="select"
                            id="userTypeId"
                            name="userTypeId"
                            class="custom-select userTypes"
                            v-model="userTypeId"
                            @change="handleUserType($event)"
                            :disabled="enableUsertypedropdown"
                            >
                            <option
                                v-for="(userType,index) in userTypes"
                                :value="userType.value"
                                v-bind:key="index"
                                >{{userType.text}}</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-7" style="text-align: right;">
                    <div class="btn-actions-pane-right actions-icon-btn">
                        <button
                            class="btn btn-warning btn-shadow"
                            v-if="continuebtn"
                            v-on:click="createUserFromShow()"
                            >Continue</button>
                    </div>
                </div>
            </div>
            <div class="divider" />
            <!-- create user form starts -->
            <div v-if="!createUserFrom">
                <form name="createUserForm" id="createUserForm" method="post" ref="createUserForm">
                    <b-row>
                        <b-col md="1"></b-col>
                        <b-col md="4">
                            <b-form-group>
                                <Label for="firstName">First Name</Label>
                                <b-form-input
                                    type="text"
                                    name="firstName"
                                    id="firstName"
                                    v-model="firstName"
                                    placeholder="First name"
                                    required
                                    title
                                    />
                                <div class="text-danger" v-if="validationErrors.firstName" style="width: 100%;">
                                    <span v-text="validationErrors.firstName"></span>
                                </div>
                                <input
                                    type="hidden"
                                    name="userTypeId"
                                    id="userTypeId"
                                    v-model="userTypeId"
                                    required
                                    />
                                <input
                                    type="hidden"
                                    name="currentLoggedInUserId"
                                    id="currentLoggedInUserId"
                                    v-model="currentLoggedInUserId"
                                    />
                                <input
                                    type="hidden"
                                    name="currentUsersUserTypeId"
                                    id="currentUsersUserTypeId"
                                    v-model="currentUsersUserTypeId"
                                    />
                                <input
                                    type="hidden"
                                    name="referenceBy"
                                    id="referenceBy"
                                    v-model="currentUsersAuthCode"
                                    />
                            </b-form-group>
                        </b-col>
                        <b-col md="2"></b-col>
                        <b-col md="4">
                            <b-form-group>
                                <Label for="lastName">Last Name</Label>
                                <b-form-input
                                    type="text"
                                    name="lastName"
                                    id="lastName"
                                    v-model="lastName"
                                    placeholder="Last name"
                                    required
                                    title
                                    />
                                <div class="text-danger" v-if="validationErrors.lastName" style="width: 100%;">
                                    <span v-text="validationErrors.lastName"></span>
                                </div>
                            </b-form-group>
                        </b-col>
                        <b-col md="1"></b-col>
                    </b-row>

                    <b-row>
                        <b-col md="1"></b-col>
                        <b-col md="4">
                            <b-form-group>
                                <Label for="email">Email Address</Label>
                                <b-form-input
                                    type="email"
                                    name="email"
                                    id="email"
                                    v-model="email"
                                    required
                                    placeholder="Enter email address"
                                    title
                                    />
                                <div class="text-danger" v-if="validationErrors.email" style="width: 100%;">
                                    <span v-text="validationErrors.email"></span>
                                </div>
                            </b-form-group>
                        </b-col>

                        <b-col md="2"></b-col>
                        <b-col md="4" v-if="companyAdminRelatedFields">
                            <b-form-group>
                                <Label for="companyName">Company Name</Label>
                                <b-form-input
                                    type="text"
                                    name="companyName"
                                    id="companyName"
                                    v-model="companyName"
                                    required
                                    placeholder="Enter Comapny Name"
                                    title
                                    />
                                <div class="text-danger" v-if="validationErrors.companyName" style="width: 100%;">
                                    <span v-text="validationErrors.companyName"></span>
                                </div>
                            </b-form-group>
                        </b-col>
                        <!-- for referral user below one field starts-->
                        <b-col md="4" v-else>
                            <b-form-group>
                                <Label for="authCode">Auth Code</Label>
                                <b-form-input
                                    type="text"
                                    name="authCode"
                                    id="authCode"
                                    v-model="authCode"
                                    placeholder="ABC123"
                                    required
                                    title
                                    />
                                <div class="text-danger" v-if="validationErrors.authCode" style="width: 100%;">
                                    <span v-text="validationErrors.authCode"></span>
                                </div>
                            </b-form-group>
                        </b-col>
                        <!-- for referral user below one field ends-->
                        <!-- used only for company admin role starts -->

                        <!-- used only for company admin role ends -->
                        <b-col md="1"></b-col>
                    </b-row>
                    <b-row>
                        <b-col md="1"></b-col>
                        <b-col md="4">
                            <b-form-group>
                                <Label for="referralCommission">Referral Commission:</Label>
                                <p>
                                    <b class="inctive_status">Disable</b>
                                <v-switch
                                    v-model="referralCommission"
                                    class="switch_set"
                                    color="success"
                                    value="Active"
                                    name="referralCommission"
                                    id="referralCommission"
                                    @change="getStatus(referralCommission)"
                                    ></v-switch>
                                <b class="active_status">Enable</b>
                                </p>
                            </b-form-group>
                        </b-col>
                        <b-col md="2"></b-col>
                        <b-col md="4" v-if="companyAdminRelatedFields">
                            <b-form-group>
                                <Label for="enableDistribution">Enable Distribution:</Label>
                                <p>
                                    <b class="inctive_status">Disable</b>
                                <v-switch
                                    v-model="enableDistribution"
                                    class="switch_set"
                                    color="success"
                                    value="Active"
                                    name="enableDistribution"
                                    id="enableDistribution"
                                    @change="getDistributionStatus(enableDistribution)"
                                    ></v-switch>
                                <b class="active_status">Enable</b>
                                </p>
                            </b-form-group>
                        </b-col>
                        <b-col md="1"></b-col>
                    </b-row>

                    <b-row v-if="isDistributionEnable">
                        <b-col md="1"></b-col>
                        <b-col md="4">
                            <b-form-group>
                                <Label for="Commission">Commission:</Label>
                                <p>
                                    <b class="inctive_status">Disable</b>
                                <v-switch
                                    v-model="distributionCommission"
                                    class="switch_set"
                                    color="success"
                                    value="Active"
                                    name="distributionCommission"
                                    id="distributionCommission"
                                    @change="getStatus(distributionCommission)"
                                    ></v-switch>
                                <b class="active_status">Enable</b>
                                </p>
                            </b-form-group>
                        </b-col>

                        <b-col md="2"></b-col>
                        <b-col md="4">
                            <b-form-group>
                                <Label for="authCode">Auth Code</Label>
                                <b-form-input
                                    type="text"
                                    name="authCode"
                                    id="authCode"
                                    v-model="authCode"
                                    placeholder="ABC123"
                                    required
                                    title
                                    />
                                <div class="text-danger" v-if="validationErrors.authCode" style="width: 100%;">
                                    <span v-text="validationErrors.authCode"></span>
                                </div>
                            </b-form-group>
                        </b-col>
                        <b-col md="1"></b-col>
                    </b-row>

                    <p></p>
                    <div style="text-align:center;">
                        <button
                            type="submit"
                            :disabled="btnLoading"
                            class="btn mr-2 mb-2 btn-square btn-success btn-shadow"
                            @click.prevent="saveAndContinue();"
                            >Save & Continue</button>
                        <button
                            type="submit"
                            :disabled="btnLoading"
                            class="btn mr-2 mb-2 btn-square btn-success btn-shadow"
                            @click.prevent="submitCreateUserForm();"
                            >Save & Exit</button>
                        <button
                            type="reset"
                            :disabled="btnLoading"
                            class="btn mr-2 mb-2 btn-square btn-light btn-shadow"
                            @click.prevent="cancelCreateUserForm();"
                            >Cancel</button>
                    </div>
                </form>
            </div>
        </b-card>
        <!-- create user form ends -->
        <!-- update form starts -->
        <b-card class="main-card mb-4" v-if="!userTbl && !createUserView">
            <div class="row">
                <div class="col-md-8">
                    <h5>{{firstName}} {{lastName}} | {{userTypeLabel}}</h5>
                </div>
                <div class="col-md-2" style="text-align: right;">
                    <div class="btn-actions-pane-right actions-icon-btn">
                        <button
                            class="btn btn-warning btn-shadow"
                            v-if="showConvertToCompanyAdminBtn"
                            >Convert to company admin</button>
                    </div>
                </div>
                <div class="col-md-2" style="text-align: right;">
                    <div class="btn-actions-pane-right actions-icon-btn">
                        <button
                            class="btn btn-warning btn-shadow"
                            v-if="!saveCancelbtn"
                            v-on:click="enableUserDetailsForm()"
                            >Edit</button>
                        <b-button
                            type="submit"
                            v-if="saveCancelbtn"
                            @click.prevent="updateUserForm();"
                            class="btn btn-success btn-shadow"
                            >Save</b-button>

                        <button
                            class="btn btn-light btn-shadow"
                            v-if="saveCancelbtn"
                            v-on:click="cancelForm()"
                            style="margin-left: 10px;"
                            >Cancel</button>
                    </div>
                </div>
            </div>
            <div class="divider" />

            <b-tabs class="card-header-tab-animation" card>
                <form id="updateUserForm" name="updateUserForm" method="post" ref="updateUserForm">
                    <b-tab title="User Details" active>
                        <b-row>
                            <b-col md="1"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="firstName">First Name</Label>
                                    <b-form-input
                                        type="text"
                                        name="firstName"
                                        id="firstName"
                                        v-model="firstName"
                                        placeholder="First name"
                                        :disabled="disabled"
                                        required
                                        title
                                        />
                                    <div class="text-danger" v-if="validationErrors.firstName" style="width: 100%;">
                                        <span v-text="validationErrors.firstName"></span>
                                    </div>
                                    <input
                                        type="hidden"
                                        name="userTypeId"
                                        id="userTypeId"
                                        v-model="userTypeId"
                                        required
                                        />
                                    <input
                                        type="hidden"
                                        name="currentLoggedInUserId"
                                        id="currentLoggedInUserId"
                                        v-model="currentLoggedInUserId"
                                        />
                                    <input
                                        type="hidden"
                                        name="currentUsersUserTypeId"
                                        id="currentUsersUserTypeId"
                                        v-model="currentUsersUserTypeId"
                                        />
                                    <input
                                        type="hidden"
                                        name="lastInsertedId"
                                        id="lastInsertedId"
                                        v-model="lastInsertedId"
                                        />
                                    <input
                                        type="hidden"
                                        name="lastInsertedCompanyId"
                                        id="lastInsertedCompanyId"
                                        v-model="lastInsertedCompanyId"
                                        />
                                    <input
                                        type="hidden"
                                        name="referenceBy"
                                        id="referenceBy"
                                        v-model="currentUsersAuthCode"
                                        />
                                </b-form-group>
                            </b-col>
                            <b-col md="2"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="lastName">Last Name</Label>
                                    <b-form-input
                                        type="text"
                                        name="lastName"
                                        id="lastName"
                                        v-model="lastName"
                                        placeholder="last name"
                                        :disabled="disabled"
                                        required
                                        title
                                        />
                                    <div class="text-danger" v-if="validationErrors.lastName" style="width: 100%;">
                                        <span v-text="validationErrors.lastName"></span>
                                    </div>
                                </b-form-group>
                            </b-col>
                            <b-col md="1"></b-col>
                        </b-row>

                        <b-row>
                            <b-col md="1"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="email">Email Address</Label>
                                    <b-form-input
                                        type="email"
                                        name="email"
                                        id="email"
                                        v-model="email"
                                        :disabled="disabled"
                                        required
                                        placeholder="Enter email address"
                                        title
                                        />
                                    <div class="text-danger" v-if="validationErrors.email" style="width: 100%;">
                                        <span v-text="validationErrors.email"></span>
                                    </div>
                                </b-form-group>
                            </b-col>

                            <b-col md="2"></b-col>
                            <b-col md="4" v-if="companyAdminRelatedFields">
                                <b-form-group>
                                    <Label for="companyName">Company Name</Label>
                                    <b-form-input
                                        type="text"
                                        name="companyName"
                                        id="companyName"
                                        v-model="companyName"
                                        :disabled="disabled"
                                        required
                                        placeholder="Enter Comapny Name"
                                        title
                                        />
                                    <div class="text-danger" v-if="validationErrors.companyName" style="width: 100%;">
                                        <span v-text="validationErrors.companyName"></span>
                                    </div>
                                    <input
                                        type="hidden"
                                        name="lastInsertedCompanyId"
                                        id="lastInsertedCompanyId"
                                        v-model="lastInsertedCompanyId"
                                        />
                                </b-form-group>
                            </b-col>
                            <!-- for referral user below one field starts-->
                            <b-col md="4" v-else>
                                <b-form-group>
                                    <Label for="authCode">Auth Code</Label>
                                    <b-form-input
                                        type="text"
                                        name="authCode"
                                        id="authCode"
                                        v-model="authCode"
                                        :disabled="disabled"
                                        placeholder="ABC123"
                                        required
                                        title
                                        />
                                    <div class="text-danger" v-if="validationErrors.authCode" style="width: 100%;">
                                        <span v-text="validationErrors.authCode"></span>
                                    </div>
                                </b-form-group>
                            </b-col>
                            <!-- for referral user below one field ends-->

                            <b-col md="1"></b-col>
                        </b-row>
                        <b-row>
                            <b-col md="1"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="referralCommission">Referral Commission:</Label>

                                    <p>
                                        <b class="inctive_status">Disable</b>
                                    <v-switch
                                        v-model="referralCommission"
                                        class="switch_set"
                                        color="success"
                                        value="Active"
                                        name="referralCommission"
                                        id="referralCommission"
                                        :disabled="disabled"
                                        @change="getReferralCommissionStatus(referralCommission)"
                                        ></v-switch>
                                    <b class="active_status">Enable</b>
                                    </p>
                                </b-form-group>
                            </b-col>
                            <b-col md="2"></b-col>
                            <b-col md="4" v-if="companyAdminRelatedFields">
                                <b-form-group>
                                    <Label for="enableDistribution">Enable Distribution:</Label>
                                    <p>
                                        <b class="inctive_status">Disable</b>
                                    <v-switch
                                        v-model="enableDistribution"
                                        class="switch_set"
                                        color="success"
                                        value="Active"
                                        name="enableDistribution"
                                        id="enableDistribution"
                                        @change="getDistributionStatus(enableDistribution)"
                                        :disabled="disabled"
                                        ></v-switch>
                                    <b class="active_status">Enable</b>
                                    </p>
                                </b-form-group>
                            </b-col>
                            <b-col md="1"></b-col>
                        </b-row>

                        <b-row v-if="isDistributionEnable">
                            <b-col md="1"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="Commission">Commission:</Label>

                                    <p>
                                        <b class="inctive_status">Disable</b>
                                    <v-switch
                                        v-model="distributionCommission"
                                        class="switch_set"
                                        color="success"
                                        value="Active"
                                        name="distributionCommission"
                                        id="distributionCommission"
                                        @change="getStatus(distributionCommission)"
                                        :disabled="disabled"
                                        ></v-switch>
                                    <b class="active_status">Enable</b>
                                    </p>
                                </b-form-group>
                            </b-col>
                            <b-col md="2"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="authCode">Auth Code</Label>

                                    <b-form-input
                                        type="text"
                                        name="authCode"
                                        id="authCode"
                                        v-model="authCode"
                                        :disabled="disabled"
                                        placeholder="ABC123"
                                        required
                                        title
                                        />
                                    <div class="text-danger" v-if="validationErrors.authCode" style="width: 100%;">
                                        <span v-text="validationErrors.authCode"></span>
                                    </div>
                                </b-form-group>
                            </b-col>
                            <b-col md="1"></b-col>
                        </b-row>
                    </b-tab>

                    <b-tab v-if="showCommisionDetail" title="Commission Details">
                        <b-row>
                            <b-col md="1"></b-col>
                            <b-col md="4">
                                <b-form-group>
                                    <Label for="referralCommissionValue">Referral Commission Value</Label>
                                    <b-form-input
                                        type="text"
                                        name="referralCommissionValue"
                                        id="referralCommissionValue"
                                        v-model="referralCommissionValue"
                                        placeholder="Referral Commission Value"
                                        :disabled="disabled"
                                        title
                                        />
                                    <div
                                        class="text-danger"
                                        v-if="validationErrors.referralCommissionValue"
                                        style="width: 100%;"
                                        >
                                        <span v-text="validationErrors.referralCommissionValue"></span>
                                    </div>
                                </b-form-group>
                            </b-col>
                            <b-col md="2"></b-col>
                            <b-col md="4" v-if="companyAdminRelatedFields">
                                <b-form-group>
                                    <Label for="distributionCommissionValue">Distribution Commission value</Label>
                                    <b-form-input
                                        type="text"
                                        name="distributionCommissionValue"
                                        id="distributionCommissionValue"
                                        v-model="distributionCommissionValue"
                                        placeholder="distribution Commission Value"
                                        :disabled="disabled"
                                        title
                                        />
                                    <div
                                        class="text-danger"
                                        v-if="validationErrors.distributionCommissionValue"
                                        style="width: 100%;"
                                        >
                                        <span v-text="validationErrors.distributionCommissionValue"></span>
                                    </div>
                                </b-form-group>
                            </b-col>
                            <b-col md="1"></b-col>
                        </b-row>
                    </b-tab>
                </form>
            </b-tabs>
        </b-card>
        <!-- update form ends -->
    </div>
</template>
<script>
    import userPageTitle from "../../../Layout/Components/userPageTitle.vue";
    import { EventBus } from "../../../main";
    import Config from "../../../config";
    const items = [];

    export default {
        components: {
            userPageTitle,
            Config
        },
        data: () => ({
                heading: "All Users > View All Users",
                subheading: "Manage all your users from here",
                icon: "pe-7s-check",

                items: items,
                fields: [
                    {key: "srno", label: "#", sortable: 1, sortDirection: "desc"},
                    {key: "username", label: "User Name", sortable: 1},
                    {key: "usertype", label: "User type", sortable: 1},
                    {key: "status", label: "Status"},
                    {key: "actions", label: "Actions"}
                ],
                currentPage: 1,
                perPage: 10,
                totalRecords: "",
                totalRows: "",
                pageOptions: [5, 10, 15],
                sortBy: null,
                sortDesc: false,
                sortDirection: "asc",
                filter: null,
                modalInfo: {title: "", content: ""},
                userTbl: true,
                createUserFrom: true,
                createUserView: true,

                disabled: true,
                enableUsertypedropdown: false,
                isDistributionEnable: false,
                continuebtn: true,
                saveCancelbtn: false,

                firstName: "",
                lastName: "",
                email: "",
                distributionCommission: "",
                referralCommission: "",
                enableDistribution: "",
                authCode: "",
                userTypeId: "", // used to pass selected userTypeId by dropdown
                userTypeLabel: "", //used to show userTypeLabel
                showCommisionDetail: false, // used to disalbe commission values tab
                currentUsersUserTypeId: "",
                currentUsersAuthCode: "",
                companyName: "",
                companyAdminRelatedFields: false,
                currentLoggedInUserId: null,
                showConvertToCompanyAdminBtn: false,
                /*For filling dropdown of usertype starts*/
                userTypes: [
                    {value: Config.companyAdmin, text: "Company Admin"},
                    {value: Config.companyUser, text: "Company User"},
                    {value: Config.referralUser, text: "Referral (No Login)"}
                ],
                /*For filling dropdown of usertype ends*/
                lastInsertedId: "",
                lastInsertedCompanyId: "",
                referralCommissionValue: "",
                distributionCommissionValue: "",
                btnLoading: false,
                /*for reverting modified values on click of cancle starts*/
                user: {
                    firstName: "",
                    lastName: "",
                    email: "",
                    authCode: "",
                    distributionCommission: "",
                    referralCommission: "",
                    distributionCommissionValue: "",
                    referralCommissionValue: "",
                    enableDistribution: "",
                    companyName: ""
                },
                /*for reverting modified values on click of cancle ends*/
                /*for maintaing form validation starts */
                validationErrors: {
                    firstName: null,
                    lastName: null,
                    email: null,
                    authCode: null,
                    companyName: null
                }
                /*for maintaing form validation ends */
            }),
        methods: {
            submitCreateUserForm() {
                if (this.validateForm("createUserForm")) {
                    this.addUser();
                }
            },
            cancelCreateUserForm(event) {
                /* reseting form errors starts*/
                this.validationErrors.firstName = null;
                this.validationErrors.lastName = null;
                this.validationErrors.email = null;
                this.validationErrors.authCode = null;
                this.validationErrors.companyName = null;
                /* reseting form errors ends*/
                this.userListing();
            },
            saveAndContinue() {
                if (this.validateForm("createUserForm")) {
                    if (this.userTypeId == Config.companyAdmin) {
                        this.userTypeLabel = "Company Admin";
                    } else if (this.userTypeId == Config.companyUser) {
                        this.userTypeLabel = "Company User";
                        this.showCommisionDetail = false; // commision realted tab
                    } else if (this.userTypeId == Config.referralUser) {
                        this.isDistributionEnable = false;
                        this.showCommisionDetail = true; // commision realted tab
                        this.userTypeLabel = "Referral User";
                    } else {
                        //   this.userTypeLabel = "Customer";
                    }
                    var self = this;
                    self.addUser("saveAndContinue");
                }
            },
            getStatus(status) {},
            //if Distrubution is enable then only show Commission & Auth Code starts
            getDistributionStatus(status) {
                if (typeof status == "string") {
                    this.isDistributionEnable = true;
                    this.showCommisionDetail = true;
                } else {
                    this.authCode = "";
                    this.distributionCommission = "";
                    this.isDistributionEnable = false;
                    this.showCommisionDetail = false;
                }
            },
            getReferralCommissionStatus(status) {
                console.log("ref :" + status);
                if (typeof status == "string") {
                    this.showCommisionDetail = true;
                } else {
                    this.showCommisionDetail = false;
                }
            },
            //if Distrubution is enable then only show Commission & Auth Code ends
            onFiltered(filteredItems) {
                // Trigger pagination to update the number of buttons/pages due to filtering
                this.totalRows = filteredItems.length;
                this.currentPage = 1;
            },
            createUserFromShow() {
                this.createUserFrom = false;
                this.enableUsertypedropdown = true;
                this.isDistributionEnable = false;
                this.continuebtn = false;
                var selectedUserTypeId = this.userTypeId;
                /*clean up values of text box starts*/
                this.firstName = "";
                this.lastName = "";
                this.email = "";
                this.authCode = "";
                this.referralCommission = "";
                this.isDistributionEnable = "";
                this.distributionCommission = "";
                /*clean up values of text box ends*/

                if (selectedUserTypeId == Config.companyAdmin) {
                    this.companyAdminRelatedFields = true;
                    console.log("companyAdmin");
                } else if (selectedUserTypeId == Config.referralUser) {
                    this.companyAdminRelatedFields = false;
                    this.showCommisionDetail = true;
                    console.log("referralUser");
                } else {
                    console.log("else part");
                }
                var userInfo = localStorage.getItem("userDetails");
                if (userInfo) {
                    if (JSON.parse(userInfo).userTypeId == Config.companyAdmin) {
                        this.currentUsersAuthCode = JSON.parse(userInfo).outhCode;
                    } else {
                        // console.log(this.userTypeId);
                        //          this.showAuthCodeContent = true;
                    }
                }
            },
            userDetailsShow() {
                this.userTbl = false;
                this.createUserFrom = false;
                this.createUserView = false;
            },
            enableUserDetailsForm() {
                this.disabled = false;
                this.saveCancelbtn = true;

                /*before edit stores data to array starts*/
                this.user.firstName = this.firstName;
                this.user.lastName = this.lastName;
                this.user.email = this.email;
                this.user.authCode = this.authCode;
                this.user.distributionCommission = this.distributionCommission;
                this.user.referralCommission = this.referralCommission;
                this.user.enableDistribution = this.enableDistribution;
                this.user.referralCommissionValue = this.referralCommissionValue;
                this.user.distributionCommissionValue = this.distributionCommissionValue;
                this.user.companyName = this.companyName;
                /*before edit store data to array ends*/
                this.heading = "All Users > Update User";
                this.subheading = "Update User account";
            },
            /* @usage       :Added to Get listing of users.
             * @method      :GET
             * @createdBy   :Amit Joshi
             * @createdAt   :31-07-2019
             */
            users() {
                var self = this;
                const param = new URLSearchParams();

                param.append("currentUsersUserTypeId", self.currentUsersUserTypeId);
                param.append("currentUsersAuthCode", self.currentUsersAuthCode);

                axios({
                    method: "get",
                    url: "UserController/getAllUsers",
                    params: param
                })
                        .then(function (response) {
                            if (response.data.status) {
                                self.items = [];
                                self.totalRecords = 0;
                                Object.keys(response.data.data).forEach(function (key) {
                                    var srno = response.data.data[key]["id"];
                                    var userName =
                                            response.data.data[key]["firstName"] +
                                            " " +
                                            response.data.data[key]["lastName"];
                                    var usertype = response.data.data[key]["userType"];
                                    var userTypeId = response.data.data[key]["userTypeId"];
                                    var status =
                                            response.data.data[key]["status"] == "1"
                                            ? "Active"
                                            : "Inactive";
                                    self.items.push({
                                        srno: srno,
                                        username: userName,
                                        usertype: usertype,
                                        userTypeId: userTypeId,
                                        status: status,
                                        actions: srno
                                    });
                                    self.totalRecords++;
                                });
                            } else {
                                //self.errorMsg(response.data.error, self.$route.name);
                            }
                            self.totalRows = self.totalRecords;
                        })
                        .catch(function (error) {});
            },
            /*users listing ends*/
            addUser(from = null) {
                var self = this;
                self.btnLoading = true;
                var formdata = new FormData(this.$refs.createUserForm);
                formdata.append("referralCommission", "0");
                formdata.append("distributionCommission", "0");
                formdata.append("enableDistribution", "0");
                if (self.referralCommission == "Active") {
                    formdata.append("referralCommission", "1");
                }

                if (self.distributionCommission == "Active") {
                    formdata.append("distributionCommission", "1");
                }

                if (self.enableDistribution == "Active") {
                    formdata.append("enableDistribution", "1");
                }

                axios({
                    method: "post",
                    url: "UserController/addUser",
                    data: formdata
                })
                        .then(function (response) {
                            if (response.data.status) {
                                self.btnLoading = false;
                                self.users();
                                if (from == null) {
                                    self.successMsg(response.data.message, self.$route.name);
                                    self.userListing();
                                    self.resetFormFields();
                                } else {
                                    self.userDetailsShow();
                                    self.lastInsertedId = response.data.lastInsertedId;
                                    self.lastInsertedCompanyId = response.data.lastInsertedCompanyId;
                                }
                            } else {
                                self.btnLoading = false;
                                self.errorMsg(response.data.message, self.$route.name);
                            }
                            // return false;
                        })
                        .catch(function (error) {});
            },
            updateUserForm() {
                if (this.validateForm("updateUserForm")) {
                    var self = this;
                    var formdata = new FormData(this.$refs.updateUserForm);
                    formdata.append("referralCommission", "0");
                    formdata.append("distributionCommission", "0");
                    formdata.append("enableDistribution", "0");

                    if (self.referralCommission == "Active") {
                        formdata.append("referralCommission", "1");
                    }
                    if (self.distributionCommission == "Active") {
                        formdata.append("distributionCommission", "1");
                    }
                    if (self.enableDistribution == "Active") {
                        formdata.append("enableDistribution", "1");
                    }
                    axios({
                        method: "post",
                        url: "UserController/updateUser",
                        data: formdata
                    })
                            .then(function (response) {
                                if (response.data.status) {
                                    self.desableUserDetailsForm();
                                    self.users();
                                    self.successMsg(response.data.message, self.$route.name);
                                    self.userListing();
                                    self.resetFormFields();
                                } else {
                                    self.errorMsg(response.data.message, self.$route.name);
                                }
                            })
                            .catch(function (error) {});
                }
            },
            viewUserById(rowObj) {
                var self = this;
                axios({
                    method: "get",
                    url: "UserController/getUserById",
                    params: {
                        userId: rowObj.item.srno,
                        userTypeId: rowObj.item.userTypeId
                    }
                })
                        .then(function (response) {
                            if (response.data.status) {
                                EventBus.$emit("msg", false);
                                self.userTypeId = response.data.data.userTypeId;
                                self.lastInsertedId = response.data.data.id;

                                var userInfo = localStorage.getItem("userDetails");
                                if (userInfo) {
                                    self.currentLoggedInUserId = JSON.parse(userInfo).userId;
                                }
                                self.enableDistribution = response.data.data.enableDistribution;
                                self.firstName = response.data.data.firstName;
                                self.lastName = response.data.data.lastName;
                                self.email = response.data.data.email;
                                self.showCommisionDetail = false;
                                self.showConvertToCompanyAdminBtn = false;
                                if (response.data.data.userTypeId == Config.companyAdmin) {
                                    self.companyName = response.data.data.companyName;
                                    self.lastInsertedCompanyId = response.data.data.companyId;
                                    self.authCode = response.data.data.outhCode;
                                    self.isDistributionEnable = true; // for showing distribution commission toggle and authcode textbox.
                                    self.companyAdminRelatedFields = true;
                                    self.userTypeLabel = "Company Admin";
                                    if (self.enableDistribution == "1") {
                                        self.enableDistribution = "Active";
                                    } else {
                                        self.enableDistribution = "";
                                        self.isDistributionEnable = false; // for showing distribution commission toggle and authcode textbox.
                                    }

                                    // self.authCode = response.data.data.authCode;
                                } else if (response.data.data.userTypeId == Config.companyUser) {
                                    self.userTypeLabel = "Company User";

                                    //   self.authCode = response.data.data.authCode;
                                } else if (response.data.data.userTypeId == Config.referralUser) {
                                    self.authCode = response.data.data.outhCode;
                                    self.userTypeLabel = "Referral User";
                                    self.showConvertToCompanyAdminBtn = true;
                                    self.companyAdminRelatedFields = false;
                                    self.isDistributionEnable = false; // for showing distribution commission toggle and authcode textbox.
                                    //   self.authCode = response.data.data.outhCode;
                                } else {
                                    //   self.userTypeLabel = "Customer";
                                }

                                if (response.data.data.distributionCommission == "1") {
                                    self.showCommisionDetail = true;
                                    self.distributionCommission = "Active";
                                    self.distributionCommissionValue =
                                            response.data.data.distributionCommissionValue;
                                }
                                if (response.data.data.referralCommission == "1") {
                                    self.showCommisionDetail = true;
                                    self.referralCommission = "Active";
                                    self.referralCommissionValue =
                                            response.data.data.referralCommissionValue;
                                }
                                self.userDetailsShow();
                            } else {
                                self.errorMsg(response.data.error);
                            }
                        })
                        .catch(function (error) {});
            },
            handleUserType(e) {
                console.log(e.target.value);
            },
            desableUserDetailsForm() {
                this.disabled = true;
                this.saveCancelbtn = false;
            },
            userListing() {
                EventBus.$emit("backmainshow", true);
                this.userTbl = true;
                this.createUserView = true;
                this.heading = "All Users > View All Users";
                this.subheading = "Manage all your users from here";
            },
            cancelForm() {
                var self = this;
                self.desableUserDetailsForm();
                /*on cancel reset old data with array values starts*/
                self.firstName = self.user.firstName;
                self.lastName = self.user.lastName;
                self.email = self.user.email;
                self.authCode = self.user.authCode;
                self.distributionCommission = self.user.distributionCommission;
                self.referralCommission = self.user.referralCommission;
                self.enableDistribution = self.user.enableDistribution;
                self.referralCommissionValue = self.user.referralCommissionValue;
                self.distributionCommissionValue = self.user.distributionCommissionValue;
                self.companyName = self.user.companyName;
                /*on cancel reset old data with array values ends*/
            },
            resetFormFields() {
                this.firstName = "";
                (this.lastName = ""), (this.email = "");
                this.distributionCommission = "";
                this.referralCommission = "";
                this.referralCommissionValue = "";
                this.distributionCommissionValue = "";
                this.authCode = "";
            }
        },

        created() {
            var userInfo = localStorage.getItem("userDetails");

            if (userInfo) {
                /*code added to show dropdown values as per user type starts at 02-08-2019 */
                let list = [];
                this.currentUsersUserTypeId = JSON.parse(userInfo).userTypeId;
                this.currentLoggedInUserId = JSON.parse(userInfo).userId;
                if (this.currentUsersUserTypeId == Config.superAdmin) {
                    this.userTypes.forEach(function (value) {
                        if (value.value != Config.companyUser) {
                            list.push(value);
                        }
                    });
                    this.userTypeId = Config.companyAdmin; //sets default selection for dropdown
                }
                //  else if (this.currentUsersUserTypeId == Config.distributer) {
                //   this.userTypes.forEach(function(value) {
                //     if (value.value == Config.companyAdmin) {
                //       list.push(value);
                //     }
                //   });
                //   this.userTypeId = Config.companyAdmin; //sets default selection for dropdown
                // }
                else if (this.currentUsersUserTypeId == Config.companyAdmin) {
                    this.userTypes.forEach(function (value) {
                        if (
                                value.value == Config.companyUser ||
                                value.value == Config.companyAdmin
                                ) {
                            list.push(value);
                        }
                    });
                    this.userTypeId = Config.companyAdmin; //sets default selection for dropdown
                } else {
                    console.log("Company User not having rights");
                }
                this.currentUsersAuthCode = JSON.parse(userInfo).outhCode;
                this.userTypes = list;
                /*code added to show dropdown values as per user type ends at 02-08-2019 */

                EventBus.$on("addUser", data => {
                    this.userTbl = false;
                    this.createUserFrom = true;
                    this.continuebtn = true;
                    this.enableUsertypedropdown = false;
                    this.disabled = true;
                    this.heading = "All Users > Create User";
                    this.subheading = "Create a New User account";
                });
                EventBus.$on("backlistclick", data => {
                    this.userTbl = data;
                    this.createUserView = data;
                    this.heading = "All Users > View All Users";
                    this.subheading = "Manage all your users from here";
                });
                this.users();
            }
        }
    };
</script>
<style>
    .dropdown-toggle::after {
        display: inline-block;
        margin-left: 0.255em;
        vertical-align: 0.255em;
        content: none !important;
        border-top: 0.3em solid;
        border-right: 0.3em solid transparent;
        border-bottom: 0;
        border-left: 0.3em solid transparent;
    }
    .dropdown-menu.show {
        display: block;
        /* margin-top: 27px; */
        left: -140px;
    }
</style>