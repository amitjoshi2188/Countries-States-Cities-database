<template>
   <div>
   <page-title :heading=heading :subheading=subheading :icon=icon></page-title>
   <!-- View All Order Start-->
   <div id="mainPage" v-if="seen && vieworderPage">
      <b-card  class="main-card mb-4">
         <b-row>
            <b-col md="4" class="my-1">
               <b-form-group horizontal label="Show Records" class="mb-0">
                  <b-form-select :options="pageOptions" v-model="perPage" />
               </b-form-group>
            </b-col>
            <b-col md="4" class="my-1">
            </b-col>
            <b-col md="4" class="my-1">
               <b-form-group horizontal label="" class="mb-0">
                  <b-input-group>
                     <b-form-input v-model="filter" placeholder="Search" />
                  </b-input-group>
               </b-form-group>
            </b-col>
         </b-row>
         <p></p>
         <!-- Main table element -->
         <b-table bordered show-empty
            stacked="md"
            :items="items"
            :fields="fields"
            :current-page="currentPage"
            :per-page="perPage"
            :filter="filter"
            :sort-by.sync="sortBy"
            :sort-direction="sortDirection"
            @filtered="onFiltered"
            >
            <template slot="srno" slot-scope="row">{{row.value}}</template>
            <template slot="productname" slot-scope="row">{{row.value}}</template>
            <template slot="price" slot-scope="row">{{row.value}}</template>
            <template slot="status" slot-scope="row">{{row.value}}</template>
            <template slot="actions" slot-scope="row">
               <i class="lnr-exit-up set_icon" v-on:click="viewOrder(row.item)"></i>&nbsp;&nbsp;&nbsp;
               <i class="lnr-cross-circle set_icon"></i>&nbsp;&nbsp;&nbsp;
               <i class="lnr-cloud-download set_icon"></i>
            </template>
            <template slot="row-details" slot-scope="row">
               <b-card class="no-shadow">
                  <ul class="list-group">
                     <li class="list-group-item" v-for="(value, key) in row.item" :key="key">{{ key }}: {{ value}}</li>
                  </ul>
               </b-card>
            </template>
         </b-table>
         <b-row>
            <b-col md="6" class="my-1">
               <b-pagination :total-rows="totalRows" :per-page="perPage" v-model="currentPage" class="my-0" />
            </b-col>
         </b-row>
      </b-card>
   </div>
   <!-- View All Order End-->
   <!-- Step page start-->
   <div id="stepOne" v-if="!seen">
   <b-card title="Create a New Order" class="main-card mb-3">
      <form-wizard title="" subtitle="" color="var(--primary)">
         <tab-content title="Step 1">
            <div class="divider"/>
            <span>Select a default Product</span>
            <div class="row">
               <div class="col-md-1"></div>
               <div class="col-md-5">
                  <div class="position-relative form-group">
                     <div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox1" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox1">Premium</label>
                        </div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox2" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox2">Premium(Complimentary)</label>
                        </div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox3" disabled class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox3">Core</label>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="position-relative form-group">
                     <div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox4" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox4">Advanced</label>
                        </div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox5" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox5">Student/Advance</label>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="divider"/>
            <span>Select payment method for this order :</span>
            <div class="row">
               <div class="col-md-1"></div>
               <div class="col-md-5">
                  <div class="position-relative form-group">
                     <div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox6" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox6">Instant card payment</label>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="position-relative form-group">
                     <div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox7" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox7">Pay by Invoice</label>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="divider"/>
            <span>Select reporting method for this order :</span>
            <div class="row">
               <div class="col-md-1"></div>
               <div class="col-md-5">
                  <div class="position-relative form-group">
                     <div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox8" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox8">Send report only to me </label>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="position-relative form-group">
                     <div>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" id="Checkbox9" class="custom-control-input">
                           <label class="custom-control-label" for="Checkbox9">Send each person a copy</label>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="divider"/>
            <span>Optional :</span>
            <div class="row">
               <Label for="exampleEmail" class="col-md-2">Select a Project to add Order to :</Label>
               <div class="col-md-3">
                  <select type="select" id="exampleCustomSelect" name="customSelect" class="custom-select">
                     <option value="">Project XYZ</option>
                     <option>Value 1</option>
                     <option>Value 2</option>
                     <option>Value 3</option>
                     <option>Value 4</option>
                     <option>Value 5</option>
                  </select>
               </div>
               <div class="col-md-7"></div>
            </div>
         </tab-content>
         <tab-content title="Step 2">
            <div class="divider"/>
            <span>Add Customers</span>
            <p></p>
            <Form>
               <b-row form>
                  <b-col md="6">
                     <b-form-group>
                        <Label for="exampleEmail">Customer First Name</Label>
                        <b-form-input type="text" name="" id="" placeholder="First Name here"/>
                     </b-form-group>
                  </b-col>
                  <b-col md="6">
                     <b-form-group>
                        <Label for="exampleEmail">Customer Last Name</Label>
                        <b-form-input type="text" name="" id="" placeholder="Last Name here"/>
                     </b-form-group>
                  </b-col>
               </b-row>
               <b-row form>
                  <b-col md="6">
                     <b-form-group>
                        <Label for="exampleEmail">Customer Email</Label>
                        <b-form-input type="email" name="" id="" placeholder="Email here"/>
                     </b-form-group>
                  </b-col>
                  <b-col md="6">
                     <div class="position-relative form-group">
                        <label for="exampleCustomSelect" class="">Customer Gender</label>
                        <select type="select" id="" name="customSelect" class="custom-select">
                           <option value="">Male</option>
                           <option>FeMale</option>
                        </select>
                     </div>
                  </b-col>
               </b-row>
               <b-row form>
                  <b-col md="6">
                     <div class="position-relative form-group">
                        <label for="exampleCustomSelect" class="">Customer Preferred Language</label>
                        <select type="select" id="" name="customSelect" class="custom-select">
                           <option value="">English</option>
                           <option>Value 1</option>
                           <option>Value 2</option>
                           <option>Value 3</option>
                           <option>Value 4</option>
                           <option>Value 5</option>
                        </select>
                     </div>
                  </b-col>
                  <b-col md="6">
                     <div class="position-relative form-group">
                        <label for="exampleCustomSelect" class="">Select Product</label>
                        <select type="select" id="exampleCustomSelect" name="customSelect" class="custom-select">
                           <option value="">Premium(Complimentary)</option>
                           <option>Value 1</option>
                           <option>Value 2</option>
                           <option>Value 3</option>
                           <option>Value 4</option>
                           <option>Value 5</option>
                        </select>
                     </div>
                  </b-col>
               </b-row>
               <b-row>
                  <b-col md="5"></b-col>
                  <b-col md="2">
                     <div class="d-flex align-items-center">
                        <button class="mb-2 mr-2 btn btn-success">Add</button>
                     </div>
                  </b-col>
                  <b-col md="5"></b-col>
               </b-row>
            </Form>
            <div class="divider"/>
            <span>Added Customers : </span>
            <p></p>
            <b-row>
               <!-- <b-col md="1"></b-col> -->
               <b-col md="12">
                  <!-- table -->
                  <b-table bordered show-empty
                     stacked="md"
                     :items="steptwoitems"
                     :fields="steptwofields"
                     :current-page="currentPage"
                     >
                     <template slot="no" slot-scope="row">{{row.value}}</template>
                     <template slot="first_name" slot-scope="row">{{row.value}}</template>
                     <template slot="email" slot-scope="row">{{row.value}}</template>
                     <template slot="product" slot-scope="row">{{row.value}}</template>
                     <template slot="mf" slot-scope="row">{{row.value}}</template>
                     <template slot="lang" slot-scope="row">{{row.value}}</template>
                     <template slot="actions">
                        <i class="lnr-pencil"></i>&nbsp;&nbsp;&nbsp;
                        <i class="lnr-trash"></i>
                     </template>
                     <template slot="row-details" slot-scope="row">
                        <b-card class="no-shadow">
                           <ul class="list-group">
                              <li class="list-group-item" v-for="(value, key) in row.item" :key="key">{{ key }}: {{ value}}</li>
                           </ul>
                        </b-card>
                     </template>
                  </b-table>
               </b-col>
               <!-- <b-col md="1"></b-col> -->
            </b-row>
         </tab-content>
         <tab-content title="Step 3">
            <div class="divider"/>
            <span>Review Your Order</span>
            <b-row>
               <b-col md="1"></b-col>
               <b-col md="6">
                  <span>Project:</span>
                  <p>(None)</p>
               </b-col>
               <b-col md="5">
                  <span>Total Cost:</span>
                  <p>$20.00</p>
               </b-col>
            </b-row>
            <div class="divider"/>
               <span>Customers : </span>
               <p></p>
               <b-row>
                  <!-- <b-col md="1"></b-col> -->
                  <b-col md="12">
                     <!-- table -->
                     <b-table bordered class="mb-0" :items="stepthreeitem" :fields="stepthreefields">
                     </b-table>
                  </b-col>
                  <!-- <b-col md="1"></b-col> -->
               </b-row>
         </tab-content>
      </form-wizard>
   </b-card>
   </div>
   <!-- Step page end-->
   <!-- View Order Start-->
   <div id="viewOrderPage" v-if="!vieworderPage">
   <b-card class="main-card mb-4">
      <b-row>
         <b-col md="8">
            <span>Batch Order# 1234</span>
         </b-col>
         <b-col md="4" style="text-align: right !important;" v-if="orderstatus==4">
            <button type="button" class="btn mr-2 mb-2 btn-success">Download Report</button>
         </b-col>  
         <b-col md="4" style="text-align: right !important;" v-if="orderstatus==2">
            <button type="button" class="btn mr-2 mb-2 btn-success">Make Payment & Submit</button>
            <button type="button" class="btn mr-2 mb-2 btn-warning">Save as Draft</button>
            <button type="button" class="btn mr-2 mb-2 btn-warning">Add Customer</button>
         </b-col>
      </b-row>
      <div class="divider"/>
      <b-row>
         <b-col md="2"></b-col>
         <b-col md="3">
            <span>Created On:</span>
            <p><b>July 7,2019</b></p>
         </b-col>
         <b-col md="3">
            <span>Project:</span>
            <p><b>(None)</b></p>
         </b-col>
         <b-col md="3">
            <span>Report to:</span>
            <p><b>Only to me </b><i class="lnr-pencil"></i></p>
         </b-col>
         <!-- <b-col md="1"></b-col> -->
      </b-row>
      <b-row>
         <b-col md="2"></b-col>
         <b-col md="3">
            <span>Total Payble:</span>
            <p>
               <b style="color:#3ac47d!important;">$20.00</b>
               <b v-if="orderstatus==2"> (Pending)</b>
               <b v-if="orderstatus!=2"> (Paid)</b>
            </p>
         </b-col>
         <b-col md="3">
            <span>Payment Method:</span>
            <p><b>Instant Card Payment</b><i class="lnr-pencil" v-if="orderstatus==2"></i></p>
         </b-col>
         <b-col md="4"></b-col>
      </b-row>
      <div class="divider"/>
         <span><b>Orders:</b></span>
         <b-row>
            <!-- <b-col md="1"></b-col> -->
            <b-col md="12">
               <!-- table -->
               <b-table bordered show-empty
                  stacked="md"
                  :items="vieworderitem"
                  :fields="vieworderfields"
                  :current-page="currentPage"
                  >
                  <template slot="order" slot-scope="row">{{row.value}}</template>
                  <template slot="customer" slot-scope="row">{{row.value}}</template>
                  <template slot="email" slot-scope="row">{{row.value}}</template>
                  <template slot="product" slot-scope="row">{{row.value}}</template>
                  <template slot="status" slot-scope="row">{{row.value}}</template>
                  <!-- <template slot="status" slot-scope="row" v-if="!orderstatus">{{statusbatch}}</template> -->
                  <template slot="last_updated" slot-scope="row">{{row.value}}</template>
                  <template slot="actions">
                     <!-- <i class="pe-7s-bottom-arrow" style="cursor:pointer;"></i> -->
                     <b-dropdown no-flip text="" class="mb-2 mr-2" menu-class="dropdown-menu-lg" variant="secondary">
                        <ul class="nav flex-column">
                           <ul class="nav flex-column">
                              <li class="nav-item" v-if="orderstatus!=4">
                                 <a href="javascript:void(0);" class="nav-link">
                                 <i class="lnr-pencil"> </i>&nbsp;&nbsp;
                                 <span v-if="orderstatus==2">Edit</span>
                                 <span v-if="orderstatus==3">Cancel Order</span>
                                 </a>
                              </li>
                              <li class="nav-item" v-if="orderstatus==2">
                                 <a href="javascript:void(0);" class="nav-link">
                                 <i class="lnr-trash"> </i>&nbsp;&nbsp;
                                 <span>Delete</span>
                                 </a>
                              </li>
                              <li class="nav-item" v-if="orderstatus!=4">
                                 <a href="javascript:void(0);" class="nav-link">
                                 <i class="lnr-envelope"> </i>&nbsp;&nbsp;
                                 <span>Resend Email</span>
                                 </a>
                              </li>
                              <li class="nav-item" v-if="orderstatus==4">
                                 <a href="javascript:void(0);" class="nav-link">
                                 <i class="lnr-file-empty"> </i>&nbsp;&nbsp;
                                 <span>View Report</span>
                                 </a>
                              </li>
                           </ul>
                        </ul>
                     </b-dropdown>
                  </template>
                  <template slot="row-details" slot-scope="row">
                     <b-card class="no-shadow">
                        <ul class="list-group">
                           <li class="list-group-item" v-for="(value, key) in row.item" :key="key">{{ key }}: {{ value}}</li>
                        </ul>
                     </b-card>
                  </template>
               </b-table>
            </b-col>
            <!-- <b-col md="1"></b-col> -->
         </b-row>
   </b-card>
   </div>
   <!-- View Order End-->
   </div>
</template>
<script>
   import PageTitle from "../../../Layout/Components/PageTitle.vue";
   import {FormWizard, TabContent} from 'vue-form-wizard';
   import  {EventBus} from '../../../main';
   // view all order table data
   const items = [
     { srno: 1234, productname: 'July 8, 2019',price: 'Paid',status : 3},
     { srno: 1235, productname: 'July 7, 2019',price: 'Pending',status : 2},
     { srno: 1236, productname: 'July 7, 2019',price: 'Paid',status : 4},
   ]
   // Step twopage table data
   const steptwoitems = [
     { no: 1, first_name: 'Nick',email: 'Nick@mail.com',product : 'Premium',mf:'M',lang:'Enaglish'},
     { no: 1, first_name: 'Maria',email: 'Maria@mail.com',product : 'Premium(Comp.)',mf:'F',lang:'French'},
   ]
   // View Order table data
   const vieworderitem = [
     { order: '1234-1', customer: 'Nick Fury',email: 'Nick@mail.com',product : 'Premium(Comp.)',status:'Draft',last_updated:'July 8,2019 10:00'},
     { order: '1234-2', customer: 'Maria Hill',email: 'Maria@mail.com',product : 'Premium',status:'Draft',last_updated:'July 8,2019 10:00'}
   ]
   export default {
     components: {
       PageTitle,
       FormWizard,
       TabContent,
     },
     data: () => ({
       heading: 'Order Central > View All Orders',
       subheading: 'View All Orders',
       icon: 'pe-7s-check',
       // view all order Start
       items: items,
       fields: [
         { key: 'srno', label: 'Sr. No.', sortable: 1, sortDirection: 'desc' },
         { key: 'productname', label: 'Product Name', sortable: 1, 'class': 'text-center' },
         { key: 'price', label: 'Price', sortable: 1, 'class': 'text-center' },
         { key: 'status', label: 'Status' },
         { key: 'actions', label: 'Actions' }
       ],
       currentPage: 1,
       perPage: 5,
       totalRows: items.length,
       pageOptions: [ 5, 10, 15 ],
       sortBy: null,
       sortDirection: 'asc',
       filter: null,
       modalInfo: { title: '', content: '' },
       // view all order End
       seen: true,
       vieworderPage: true,
       orderstatus:1,
       // step Three table fields Start
       stepthreefields: [
            {key: '#'},
            {key: 'first'},
            {key: 'last'},
            {key: 'email'},
            {key: 'product'},
            {key: 'M/F'},
            {key: 'language'}
      ],
      stepthreeitem: [
            { '#': 1, first: 'Nick',last:'Fury', email: 'Nick@mail.com',product:'Premium','M/F':'M' ,language:'English'},
            { '#': 2, first: 'Maria',last:'Hill', email: 'Nick@mail.com',product:'Premium','M/F':'M' ,language:'English'}
      ],
      // step Three table fields End
      // step Two table fields Start
      steptwoitems: steptwoitems,
      steptwofields: [
         { key: 'no', label: '#', sortable: 1, sortDirection: 'desc' },
         { key: 'first_name', label: 'First Name', sortable: 1, 'class': 'text-center' },
         { key: 'email', label: 'Email', sortable: 1, 'class': 'text-center' },
         { key: 'product', label: 'Product' },
         { key: 'mf', label: 'M/F' },
         { key: 'lang', label: 'Lang.' },
         { key: 'actions', label: 'Actions' }
       ],
       // step Two table fields End
       // View Order fields Start
       vieworderitem: vieworderitem,
       vieworderfields: [
            { key: 'order', label: 'Order#', sortable: 1, sortDirection: 'desc' },
            { key: 'customer', label: 'Customer', sortable: 1, 'class': 'text-center' },
            { key: 'email', label: 'Email', sortable: 1, 'class': 'text-center' },
            { key: 'product', label: 'Product' ,sortable: 1, 'class': 'text-center'},
            { key: 'status', label: 'Status' ,sortable: 1, 'class': 'text-center'},
            { key: 'last_updated', label: 'Last Updated.' ,sortable: 1, 'class': 'text-center' },
            { key: 'actions', label: 'Actions' ,sortable: 1, 'class': 'text-center'}
       ],
       statusbatch : 'Email Sent'
       // View Order fields End
     }),
     created() {
       EventBus.$on("emaitdata", data=>{
         this.seen = data;
         this.heading = "Order Central > Create a New order";
         this.subheading = "Create a New order";
       })
       EventBus.$on("backlistclick", data=>{
         this.seen = data;
         this.vieworderPage = data;
         this.heading = "Order Central > View All Orders";
         this.subheading = "View All Orders";
       })
     },
     mounted() {
       EventBus.$on("firstpage", data=>{
         this.seen = data;
         this.heading = "Order Central > View All Orders";
         this.subheading = "View All Orders";
       })
     },
     computed: {
       sortOptions () {
         // Create an options list from our fields
         return this.fields
         .filter(f => f.sortable)
         .map(f => { return { text: f.label, value: f.key } })
       }
     },
     methods: {
       info (item, index, button) {
         this.modalInfo.title = `Row index: ${index}`
         this.modalInfo.content = JSON.stringify(item, null, 2)
         this.$root.$emit('bv::show::modal', 'modalInfo', button)
       },
       resetModal () {
         this.modalInfo.title = ''
         this.modalInfo.content = ''
       },
       onFiltered (filteredItems) {
         // Trigger pagination to update the number of buttons/pages due to filtering
         this.totalRows = filteredItems.length
         this.currentPage = 1
       },// handal click view Order page show
       viewOrder(item){
          if(item.price == 'Paid'){
             if(item.status == 4){
                this.orderstatus = 4;
                this.heading = "Order Central > View Batch Order";
             }else{
                this.orderstatus = 3;
                this.heading = "Order Central > View Batch Order";
             }
          }else{
             this.orderstatus = 2;
               this.heading = "Order Central > View Order";
          }
          this.vieworderPage = false;
          this.subheading = "View Order Details";
          EventBus.$emit("orderviewbtnset",this.vieworderPage);
       }
     },
   }
</script>
<style>
   .set_icon{
      font-size: 20px;
      cursor: pointer;
   }
</style>
