
<template>
  <div>
    <transition name="fade" mode="out-in" appear>
      <div class="h-100">
        <b-row class="h-100 no-gutters">
          <b-col lg="4" class="d-none d-lg-block">
            <div class="slider-light">
              <slick ref="slick" :options="slickOptions6">
                <div
                  class="position-relative h-100 d-flex justify-content-center align-items-center bg-plum-plate"
                >
                  <div class="slide-img-bg" />
                  <div class="slider-content text-light">
                    <h3>Perfect Balance</h3>
                    <p>ArchitectUI is like a dream. Some think it's too good to be true! Extensive collection of unified Vue Bootstrap Components and Elements.</p>
                  </div>
                </div>
                <div
                  class="position-relative h-100 d-flex justify-content-center align-items-center bg-premium-dark"
                >
                  <div class="slide-img-bg" />
                  <div class="slider-content text-light">
                    <h3>Scalable, Modular, Consistent</h3>
                    <p>
                      Easily exclude the components you don't require. Lightweight, consistent
                      Bootstrap based styles across all elements and components
                    </p>
                  </div>
                </div>
                <div
                  class="position-relative h-100 d-flex justify-content-center align-items-center bg-sunny-morning"
                >
                  <div class="slide-img-bg opacity-6" />
                  <div class="slider-content text-light">
                    <h3>Complex, but lightweight</h3>
                    <p>
                      We've included a lot of components that cover almost all use cases for
                      any type of application.
                    </p>
                  </div>
                </div>
              </slick>
            </div>
          </b-col>
          <b-col
            lg="8"
            md="12"
            class="h-100 d-flex bg-white justify-content-center align-items-center"
          >
            <b-col lg="9" md="10" sm="12" class="mx-auto app-login-box">
              <h4 class="mb-0">
                <div>
                  <b>Welcome back,</b>
                  <span>Please sign in to your account.</span>
                </div>
              </h4>

              <div class="divider" />
              <div>
                <Form name="adminLoginForm" id="adminLoginForm" method="post" ref="adminLoginForm">
                  <b-row form>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="exampleEmail">Email</Label>
                        <b-form-input
                          type="email"
                          name="email"
                          v-model="email"
                          id="email"
                          required
                          placeholder="Email here..."
                          title
                        />
                        <div class="text-danger" v-if="validationErrors.email" style="width: 100%;">
                          <span v-text="validationErrors.email"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="examplePassword">Password</Label>
                        <b-form-input
                          type="password"
                          name="password"
                          v-model="password"
                          id="password"
                          required
                          placeholder="Password here..."
                          @enter="doLogin();"
                          title
                        />
                        <div
                          class="text-danger"
                          v-if="validationErrors.password"
                          style="width: 100%;"
                        >
                          <span v-text="validationErrors.password"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                  </b-row>
                  <b-row>
                    <b-col md="8">
                      <b-form-checkbox name="check" id="exampleCheck">Remember Me</b-form-checkbox>
                    </b-col>
                    <b-col md="4">
                      <a
                        href="javascript:void(0);"
                        class="btn-lg btn btn-link"
                      >Recover your password</a>
                    </b-col>
                  </b-row>
                  <div class="divider" />
                  <b-row>
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                          <b-button
                            type="submit"
                            @click.prevent="doLogin();"
                            variant="primary"
                            class="btn_width btn-shadow"
                            size="lg"
                          >Login to Dashboard</b-button>
                        </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>
                  <!-- <b-row style=" margin-top: 15px !important;">
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                  <b-button variant="primary" class="btn_width " size="lg" v-on:click="gLogin">Google Login</b-button>-->
                  <!--<button type="button" class="btn mr-2 mb-2 btn-icon btn-success">Google Login</button> -->
                  <!-- </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>-->
                  <!-- <b-row style=" margin-top: 15px !important;">
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                  <b-button variant="primary" class="btn_width" size="lg" v-on:click="fLogin">Facebook Login</b-button>-->
                  <!-- <button type="button" class="btn mr-2 mb-2 btn-icon btn-success">Facebook Login</button> -->
                  <!-- </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>-->

                  <!-- <b-row style=" margin-top: 15px !important;">
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                          <b-button
                            variant="primary"
                            class="btn_width"
                            size="lg"
                            v-on:click="tLogin"
                          >Twitter Login</b-button>
                        </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>-->
                </Form>
              </div>
            </b-col>
          </b-col>
        </b-row>
      </div>
    </transition>
  </div>
</template>

<script>
import Slick from "vue-slick";
import Config from "../../config";
export default {
  components: {
    Slick
  },
  mounted() {
    console.log("Component mounted.");
  },
  data: function() {
    return {
      slickOptions6: {
        dots: true,
        infinite: true,
        speed: 500,
        arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        fade: true,
        initialSlide: 0,
        autoplay: true,
        adaptiveHeight: true
      },
      slide: 0,
      sliding: null,
      email: "",
      password: "",
      validationErrors: {
        email: null,
        password: null
      }
    };
  },
  methods: {
    /* @usage       :Added for Super Admin Login.
     * @method      :POST
     * @param       :email         (STRING)
     * @param       :password      (STRING)
     * @createdBy   :Amit Joshi
     * @createdAt   :31-07-2019
     */
    doLogin() {
      if (this.validateForm("adminLoginForm")) {
        var self = this;
        if (this.email == "" || this.password == "") {
          self.warningMsg(
            "Email id & password both fields are required",
            self.$route.name
          );
        } else {
          var formdata = new FormData();
          formdata.append("email", this.email);
          formdata.append("password", this.password);
          axios({
            method: "post",
            url: "auth/adminLogin",
            data: formdata
          })
            .then(function(response) {
              if (response.data.status) {
                var userId = response.data.data.id;
                var userTypeId = response.data.data.userTypeId;
                var email = response.data.data.email;
                var name = response.data.data.name;
                var outhCode = response.data.data.outhCode;

                var userDetails = {
                  userId: userId,
                  isLoggedIn: true,
                  userTypeId: userTypeId,
                  email: email,
                  name: name,
                  outhCode: outhCode
                };
                localStorage.setItem(
                  "userDetails",
                  JSON.stringify(userDetails)
                );
                //self.successMsg(response.data.message, self.$route.name);
                if (userTypeId == Config.superAdmin) {
                  self.$router.push("/Admin/Dashboard");
                }
              } else {
                self.errorMsg(response.data.message, self.$route.name);
              }
            })
            .catch(function(error) {
              console.log(error);
            });
        }
      }
    }
    // gLogin() {
    //   console.log("glogin called");
    //   var self = this;
    //   axios
    //     .get("auth/glogin", {
    //       params: {}
    //     })
    //     .then(response => {
    //       if (response.data.redirectURL != "") {
    //         console.log(response.data.redirectURL);
    //         window.open(response.data.redirectURL, "_self");
    //       }
    //     })
    //     .catch(error2 => {
    //       console.log(error2);
    //     });
    // },
    // fLogin() {
    //   var self = this;
    //   console.log("flogin called");
    //   axios
    //     .get("auth/flogin", {
    //       params: {}
    //     })
    //     .then(response => {
    //       console.log(response.data);
    //       if (response.data.status) {
    //         console.log(response.data.redirectURL);
    //         window.open(response.data.redirectURL, "_self");
    //       }
    //     })
    //     .catch(error2 => {
    //       console.log(error2);
    //     });
    // }
    // tLogin() {
    //   var self = this;
    //   console.log("twitter login called");
    //   axios
    //     .get("User/tLogin", {})
    //     .then(response => {
    //       if (response.data.status) {
    //         console.log(response.data.redirectURL);
    //         window.open(response.data.redirectURL, "_self");
    //       }
    //     })
    //     .catch(error2 => {
    //       console.log(error2);
    //     });
    // }
  }
};
</script>
<style>
.h-100 {
  height: 100vh !important;
}
.btn_width {
  width: 75% !important;
}
</style>
