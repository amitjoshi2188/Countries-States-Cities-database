<template>
  <div>
    <transition name="fade" mode="out-in" appear>
      <div class="h-100">
        <b-row class="h-100 no-gutters">
          <b-col lg="4" class="d-none d-lg-block">
            <div class="slider-light">
              <slick ref="slick" :options="slickOptions6">
                <div
                  class="position-relative h-100 d-flex justify-content-center align-items-center bg-plum-plate"
                >
                  <div class="slide-img-bg" />
                  <div class="slider-content text-light">
                    <h3>Perfect Balance</h3>
                    <p>ArchitectUI is like a dream. Some think it's too good to be true! Extensive collection of unified Vue Bootstrap Components and Elements.</p>
                  </div>
                </div>
                <div
                  class="position-relative h-100 d-flex justify-content-center align-items-center bg-premium-dark"
                >
                  <div class="slide-img-bg" />
                  <div class="slider-content text-light">
                    <h3>Scalable, Modular, Consistent</h3>
                    <p>
                      Easily exclude the components you don't require. Lightweight, consistent
                      Bootstrap based styles across all elements and components
                    </p>
                  </div>
                </div>
                <div
                  class="position-relative h-100 d-flex justify-content-center align-items-center bg-sunny-morning"
                >
                  <div class="slide-img-bg opacity-6" />
                  <div class="slider-content text-light">
                    <h3>Complex, but lightweight</h3>
                    <p>
                      We've included a lot of components that cover almost all use cases for
                      any type of application.
                    </p>
                  </div>
                </div>
              </slick>
            </div>
          </b-col>
          <b-col
            lg="8"
            md="12"
            class="h-100 d-flex bg-white justify-content-center align-items-center"
            v-if="seen"
          >
            <b-col lg="9" md="10" sm="12" class="mx-auto app-login-box">
              <h4 class="mb-0">
                <div>
                  <b>SIGN UP</b>
                </div>
                <span>This section of the PRO-D Website is restricted to PRO-D Approved</span>
                <p>
                  <span>coaches. If you have not received an Auth Code please contact support.</span>
                </p>
              </h4>
              <div>
                <Form
                  name="validateAuthCode"
                  id="validateAuthCode"
                  method="post"
                  ref="validateAuthCode"
                >
                  <b-row form>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="authCode">Enter Auth Code</Label>
                        <b-form-input
                          type="text"
                          name="authCode"
                          id="authCode"
                          v-model="authCode"
                          @enter="submitForm()"
                          title
                          required
                          placeholder="ABC123"
                        />
                        <div
                          class="text-danger"
                          v-if="validationErrors.authCode"
                          style="width: 100%;"
                        >
                          <span v-text="validationErrors.authCode"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                  </b-row>
                  <div class="divider" />
                  <b-row>
                    <b-col md="8">
                      <span>
                        Already have an account?
                        <router-link to="/" class="button is-primary">Sign in</router-link>
                      </span>
                    </b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto" style="text-align: right !important;">
                          <b-button
                            type="submit"
                            @click.prevent="submitForm();"
                            variant="primary"
                            class="btn-shadow"
                            size="lg"
                          >Proceed to Sign-up</b-button>
                        </div>
                      </div>
                    </b-col>
                  </b-row>
                </Form>
              </div>
            </b-col>
          </b-col>
          <b-col
            lg="8"
            md="12"
            class="h-100 d-flex bg-white justify-content-center align-items-center"
            v-if="!seen"
          >
            <b-col lg="9" md="10" sm="12" class="mx-auto app-login-box">
              <h4 class="mb-0">
                <div>
                  <b>SIGN UP</b>
                </div>
                <span>Enter the required details below to complete sign-up</span>
                <p>
                  <span>
                    Already have an account?
                    <router-link to="/" class="button is-primary">Sign in</router-link>
                  </span>
                </p>
              </h4>
              <div>
                <Form name="signupForm" id="signupForm" method="post" ref="signupForm">
                  <b-row form>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="firstName">Enter your First Name</Label>
                        <b-form-input
                          type="text"
                          name="firstName"
                          id="firstName"
                          v-model="firstName"
                          required
                          placeholder="First Name here"
                          title
                        />
                        <div
                          class="text-danger"
                          v-if="validationErrors.firstName"
                          style="width: 100%;"
                        >
                          <span v-text="validationErrors.firstName"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="examplePassword">Enter your Last Name</Label>
                        <b-form-input
                          type="text"
                          name="lastName"
                          id="lastName"
                          required
                          v-model="lastName"
                          placeholder="Last Name here"
                          title
                        />
                        <div
                          class="text-danger"
                          v-if="validationErrors.lastName"
                          style="width: 100%;"
                        >
                          <span v-text="validationErrors.lastName"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                  </b-row>
                  <b-row form>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="email">Enter your Email</Label>
                        <b-form-input
                          type="email"
                          name="email"
                          id="email"
                          v-model="email"
                          required
                          placeholder="Email here"
                          title
                        />
                        <input type="hidden" name="referenceBy" id="referenceBy" v-model="authCode" />
                        <div class="text-danger" v-if="validationErrors.email" style="width: 100%;">
                          <span v-text="validationErrors.email"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                    <b-col md="6">
                      <b-form-group>
                        <Label for="companyName">Company Name</Label>
                        <b-form-input
                          type="text"
                          name="companyName"
                          id="companyName"
                          v-model="companyName"
                          required
                          placeholder="Enter Comapny Name"
                          title
                        />
                        <div
                          class="text-danger"
                          v-if="validationErrors.companyName"
                          style="width: 100%;"
                        >
                          <span v-text="validationErrors.companyName"></span>
                        </div>
                      </b-form-group>
                    </b-col>
                  </b-row>
                  <b-row>
                    <b-col md="8">
                      <span>
                        By signing up, I agree to the
                        <a
                          href="javascript:void(0);"
                          class="btn-link"
                        >Privacy Policy</a>
                        <span>and the</span>
                        <a href="javascript:void(0);" class="btn-link">Terms of Services.</a>
                      </span>
                    </b-col>
                  </b-row>
                  <div class="divider" />
                  <b-row>
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                          <b-button
                            variant="primary"
                            size="lg"
                            class="btn_width btn-shadow"
                            type="submit"
                            :disabled="btnLoading"
                            @click.prevent="submitSignupForm();"
                          >Complete Sign-up</b-button>
                        </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>
                  <b-row style=" margin-top: 15px !important;">
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                          <b-button
                            variant="primary"
                            size="lg"
                            class="btn_width btn-shadow"
                            v-on:click="gSignup"
                            :disabled="btnLoading"
                          >Sign up With Google</b-button>
                          <!--  <button type="button" class="btn mr-2 mb-2 btn-icon btn-success btn_width">Sign up With Google</button> -->
                        </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>
                  <b-row style=" margin-top: 15px !important;">
                    <b-col md="5"></b-col>
                    <b-col md="4">
                      <div class="d-flex align-items-center">
                        <div class="ml-auto">
                          <b-button
                            variant="primary"
                            size="lg"
                            class="btn_width btn-shadow"
                            v-on:click="fSignup"
                            :disabled="btnLoading"
                          >Sign up With Facebook</b-button>
                          <!-- <button type="button" class="btn mr-2 mb-2 btn-icon btn-success btn_width">Sign up With Facebook</button> -->
                        </div>
                      </div>
                    </b-col>
                    <b-col md="3"></b-col>
                  </b-row>
                </Form>
              </div>
            </b-col>
          </b-col>
        </b-row>
      </div>
    </transition>
  </div>
</template>

<script>
import Slick from "vue-slick";

export default {
  components: {
    Slick
  },
  data: () => ({
    slickOptions6: {
      dots: true,
      infinite: true,
      speed: 500,
      arrows: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      fade: true,
      initialSlide: 0,
      autoplay: true,
      adaptiveHeight: true
    },

    slide: 0,
    sliding: null,
    seen: true,
    email: "",
    firstName: "",
    lastName: "",
    authCode: "",
    companyName: "",
    btnLoading: false,
    validationErrors: {
      authCode: null,
      email: null,
      firstName: null,
      lastName: null,
      companyName: null
    }
  }),

  methods: {
    handleClick(newTab) {
      this.currentTab = newTab;
    },
    next() {
      this.$refs.slick.next();
    },

    prev() {
      this.$refs.slick.prev();
    },

    reInit() {
      this.$nextTick(() => {
        this.$refs.slick.reSlick();
      });
    },
    submitForm() {
      if (this.validateForm("validateAuthCode")) {
        var self = this;
        if (this.authCode == "") {
          self.warningMsg("auth Code is required", self.$route.name);
        } else {
          var formdata = new FormData(this.$refs.validateAuthCode);

          //  var formdata = new FormData();
          //  formdata.append("authCode", this.authCode);
          axios({
            method: "post",
            url: "auth/validateAuthCode",
            data: formdata
          })
            .then(function(response) {
              if (response.data.status) {
                self.seen = false;
              } else {
                self.seen = true;
                self.errorMsg(response.data.message, self.$route.name);
              }
            })
            .catch(function(error) {
              console.log(error);
            });
        }
      }
    },
    submitSignupForm() {
      if (this.validateForm("signupForm")) {
        var self = this;
        self.btnLoading = true;
        if (this.authCode == "") {
          self.warningMsg("auth Code is required", self.$route.name);
        } else {
          var formData = new FormData(this.$refs.signupForm);
          axios({
            method: "post",
            url: "auth/signup",
            data: formData
          })
            .then(function(response) {
              if (response.data.status) {
                self.btnLoading = false;
                //self.seen =false;
                self.successMsg(response.data.message, self.$route.name);
                var userId = response.data.data.id;
                var userTypeId = response.data.data.userTypeId;
                var email = response.data.data.email;
                var name = response.data.data.name;
                var outhCode = response.data.data.outhCode;

                var userDetails = {
                  userId: userId,
                  isLoggedIn: true,
                  userTypeId: userTypeId,
                  email: email,
                  name: name,
                  outhCode: outhCode
                };
                // localStorage.setItem("userDetails", JSON.stringify(userDetails));
                //self.$router.push("/dashboard");
                self.$router.push("/");
              } else {
                self.btnLoading = false;
                //  self.seen =true;
                self.errorMsg(response.data.message, self.$route.name);
              }
            })
            .catch(function(error) {
              console.log(error);
            });
        }
      }
    },
    gSignup() {
      console.log("gSignup called");
      var self = this;
      axios
        .get("auth/glogin", {
          params: {
            referenceBy: this.authCode
          }
        })
        .then(response => {
          if (response.data.redirectURL != "") {
            console.log(response.data.redirectURL);
            window.open(response.data.redirectURL, "_self");
          }
        })
        .catch(error2 => {
          console.log(error2);
        });
    },
    fSignup() {
      var self = this;
      console.log("fSignup called");
      axios
        .get("auth/flogin", {
          params: {
            referenceBy: this.authCode
          }
        })
        .then(response => {
          console.log(response.data);
          if (response.data.status) {
            console.log(response.data.redirectURL);
            window.open(response.data.redirectURL, "_self");
          }
        })
        .catch(error2 => {
          console.log(error2);
        });
    }
  }
};
</script>
<style>
.h-100 {
  height: 100vh !important;
}
.btn_width {
  width: 86% !important;
}
</style>
